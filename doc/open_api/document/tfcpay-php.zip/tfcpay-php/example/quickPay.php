<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <title>支付样例- 快捷支付1(同名进出)</title>
</head>
<?php

require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * AGENT_MID：机构商户号
 * KEY：支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * @var string
 */
/** 机构商户号 **/
const  AGENT_MID = "822017081624283";
const KEY="83eslyjjsjr7hj2brh9z";

const gateUrl="https://devapi.tfcpay.com/v2/quickPay/mobilePay";


//订单号
$orderNo = Util::getNonceStr();

if(isset($_REQUEST["amount"]) && $_REQUEST["amount"] != ""){
    $amount=$_REQUEST["amount"];
    //输入参数
    $input=array(
        'mid' => AGENT_MID,                              // 商户号
        'orderNo' =>$orderNo,                             // 商户系统中的订单号
        'amount' => $amount,                                // 交易的总金额，单位为元
        'subject'=>'subject',                               //商品的标题
        'body'=>'大桶可口可乐',                            //商品的具体描述
        'bankCardNo'=>'62531642312718912',                                //付款方银行卡号
        'feeRate'=>'0.33',
        'mustAmt'=>'30',
        'receivedCardNo'=>'621483011224878',
        'receivedCardId'=>'41152819123083499',
        'receivedRealName'=>'刘新',
        'receivedPhoneNo'=>'15311372348',                     //手机号
        'receivedBankCode'=>'105',
    );

    $request=new RequestHandler();
    $request->setGateURL(gateUrl);
    $request->setReqParams($input);
    $request->setKey(KEY);
    //发送请求参数
    $result=$request->call();

}

/**
 * 注意：
 * 1、提交被扫之后，返回系统繁忙、用户输入密码等错误信息时需要循环查单以确定是否支付成功
 * 2、多次（一半10次）确认都未明确成功时需要调用撤单接口撤单，防止用户重复支付
 */

?>
<body>
<form action="#" method="post">

    <div style="margin-left:2%;">
        快捷1(同名进出)，提供两种方式，1、api直连。2.手机sdk支付（目前只能使用该模式）
    </div>
    <br/>
    <input type="text" style="width:96%;height:35px;margin-left:2%;" name="amount" value="15356.25" placeholder="金额" /><br /><br />
    <div align="center">
        <pre>点击下面按钮进行模拟操作</pre>
        <input type="submit" value="提交" style="width:210px; height:50px; border-radius: 15px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;" type="button" onclick="callpay()" />
    </div>
</form>
</body>
</html>