<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <title>支付样例- 刷卡相关示例</title>
</head>
<?php

require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * KEY：商户支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * notifyUrl：异步通知地址
 * @var string
 */
const MID="812017090824399";
const KEY="amlzh0yqgouyavnhfrob";
const notifyUrl=TFCPayConfig::NOTIFY_URL;;
const gateUrl="https://devapi.tfcpay.com/v2/pay/brushcard";


//订单号
$orderNo = Util::getNonceStr();

//打印输出数组信息
function printf_info($data)
{
    foreach($data as $key=>$value){
        echo "<font color='#00ff55;'>$key</font> : $value <br/>";
    }
}

if(isset($_REQUEST["authCode"]) && $_REQUEST["authCode"] != ""){
	$auth_code = $_REQUEST["authCode"];
    $type = $_REQUEST["type"];
    $amount=$_REQUEST['amount'];
    //输入参数
    $input=array( 'mid' => MID,
        'orderNo' => $orderNo,
        'subject' => 'round',
        'body'  => 'apple',
        'amount'=>$amount,
        'deviceInfo'=>'',
        'authCode'=>$auth_code,    //授权码，必须
        'type'=>$type,   // 支付类型 wechat:微信 alipay:支付宝 QQwallet:QQ钱包
    );

    $request=new RequestHandler();
    $request->setGateURL(gateUrl);
    $request->setReqParams($input);
    $request->setKey(KEY);
    //发送请求参数
    $result=$request->call();

}

/**
 * 注意：
 * 1、提交被扫之后，返回系统繁忙、用户输入密码等错误信息时需要循环查单以确定是否支付成功
 * 2、多次（一半10次）确认都未明确成功时需要调用撤单接口撤单，防止用户重复支付
 */

?>
<body>  
	<form action="#" method="post">
        <div style="margin-left:2%;">商品描述：</div><br/>
        <input type="text" style="width:96%;height:35px;margin-left:2%;" readonly value="刷卡测试样例-支付" name="auth_code" /><br /><br />
        <div style="margin-left:2%;">支付金额：</div><br/>
        <input type="text" style="width:96%;height:35px;margin-left:2%;" readonly value="0.05" name="amount" /><br /><br />
        <div style="margin-left:2%;">支付类型：</div><br/>
        <input type="text" style="width:96%;height:35px;margin-left:2%;" readonly value="wechat" name="type" /><br /><br />
        <div style="margin-left:2%;">授权码：</div><br/>
        <input type="text" style="width:96%;height:35px;margin-left:2%;" name="authCode" /><br /><br />
       	<div align="center">
			<input type="submit" value="提交刷卡" style="width:210px; height:50px; border-radius: 15px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;" type="button" onclick="callpay()" />
		</div>
	</form>
</body>
</html>