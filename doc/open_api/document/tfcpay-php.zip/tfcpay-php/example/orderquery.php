<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <title>支付样例-订单查询</title>
</head>
<?php
require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * KEY：商户支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * notifyUrl：异步通知地址
 * @var string
 */
const MID="812017090824399";
const KEY="amlzh0yqgouyavnhfrob";
const notifyUrl=TFCPayConfig::NOTIFY_URL;;
const gateUrl="https://devapi.tfcpay.com/v2/query/single";

//打印输出数组信息
function printf_info($data)
{
    foreach($data as $key=>$value){
        echo "<font color='#00ff55;'>$key</font> : $value <br/>";
    }
}


if(isset($_REQUEST["orderNo"]) && $_REQUEST["orderNo"] != ""){
	$out_trade_no = $_REQUEST["orderNo"];
    $input=array( 'mid' => MID,
        'orderNo' => $out_trade_no
    );

    $request=new RequestHandler();
    $request->setGateURL(gateUrl);
    $request->setReqParams($input);
    $request->setKey(KEY);
    //发送请求参数
    $result=$request->call();

}
?>
<body>  
	<form action="#" method="post">
        <div style="margin-left:2%;color:#f00"></div><br/>

        <div style="margin-left:2%;">商户订单号：</div><br/>
        <input type="text" style="width:96%;height:35px;margin-left:2%;" name="orderNo" /><br /><br />
		<div align="center">
			<input type="submit" value="查询" style="width:210px; height:50px; border-radius: 15px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;" type="button" onclick="callpay()" />
		</div>
	</form>
</body>
</html>