<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <title>支付样例- 商户报备</title>
</head>
<?php

require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * AGENT_MID：机构商户号
 * KEY：支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * notifyUrl：异步通知地址
 * @var string
 */
/** 机构商户号 **/
const  AGENT_MID = "812017081524279";
const KEY="q485ghzz6nmr5duhctal";
const notifyUrl=TFCPayConfig::NOTIFY_URL;

const gateUrl="https://devapi.tfcpay.com/v2/merchant/register";


//订单号
$orderNo = Util::getNonceStr();

if(isset($_REQUEST["AGENT_MID"]) && $_REQUEST["AGENT_MID"] != ""){
    //输入参数
    $input=array(
        'mid' => AGENT_MID,                              // 机构商户号
        'merchantName' => 'demo:register测试商户',      // 商户名称
        'merchantAlias' => '商户简称',                   // 商户简称
        'realName'=>'东皇太一',                               //法人姓名				个人用户请填写身份证姓名
        'idCard'=>'41152564545665465555',                //法人身份证				个人用户请填写身份证号
        'businessContact'=>'张某某',                       //联系人姓名
        'phoneNumber'=>'15655646565',                   //联系人电话
        'alipayCategory'=>'2016062900190116',             //支付宝经营类目
        'weChatCategory'=>'9',                              //微信经营类目
        'bankCard'=>'621489265689856',                     //银行卡号
        'bankLinked'=>'104171306669',                       //联行号
        'cardAccountType'=>'01',                            //卡账户类型 01 个人 02 企业
        'creditBankCard'=>'6222111111111111111',           //信用卡号
        'creditBankLinked'=>'102100020794',                  //信用卡联行号
        //拓展信息见文档中的拓展信息描述
        'extendParams'=>'{"03":[{"811":"0.1"}],"04":[{"01":"0.2"}],"00":[{"D0":"0.13"},{"T1":"0.14"}]}'
    );

    $request=new RequestHandler();
    $request->setGateURL(gateUrl);
    $request->setReqParams($input);
    $request->setKey(KEY);
    //发送请求参数
    $result=$request->call();

}

/**
 * 注意：
 * 1、提交被扫之后，返回系统繁忙、用户输入密码等错误信息时需要循环查单以确定是否支付成功
 * 2、多次（一半10次）确认都未明确成功时需要调用撤单接口撤单，防止用户重复支付
 */

?>
<body>
<form action="#" method="post">

    <div style="margin-left:2%;">机构号：</div><br/>
    <input type="text" style="width:96%;height:35px;margin-left:2%;" name="AGENT_MID" value="812017081524279" /><br /><br />
    <div align="center">
        <input type="submit" value="提交报备" style="width:210px; height:50px; border-radius: 15px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;" type="button" onclick="callpay()" />
    </div>
</form>
</body>
</html>