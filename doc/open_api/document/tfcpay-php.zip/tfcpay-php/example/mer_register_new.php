<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" /> 
    <title>支付样例- 商户报备(新)</title>
</head>
<?php

require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * AGENT_MID：机构商户号
 * KEY：支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * notifyUrl：异步通知地址
 * @var string
 */
/** 机构商户号 **/
const  AGENT_MID = "812017081524279";
const KEY="q485ghzz6nmr5duhctal";
const notifyUrl=TFCPayConfig::NOTIFY_URL;

const gateUrl="https://devapi.tfcpay.com/v2/merchant/create";


//订单号
$orderNo = Util::getNonceStr();

if(isset($_REQUEST["AGENT_MID"]) && $_REQUEST["AGENT_MID"] != ""){
    //输入参数
    $input=array(
        'mid' => AGENT_MID,                              // 机构商户号
        'merchantName' => 'demo:registerNew测试商户',  // 商户名称
        'merchantAlias' => '商户简称',                   // 商户简称
        'province'  => '110000',                         //省市编码见附件
        'city'=>'110100',                                 //省市编码见附件
        'county'=>'110101',
        'address'=>'北京市通州区万达广场',                 //商户地址
        'merchantEmail'=>'test@163.com',                 //商户邮箱
        'licenceType'=>'02',                              //商户营业类型编号	00：三证合一，01：企业法人，02：个体工商户，03：个人独资企业，04：合伙企业，05：农民专业合作社，06：事业单位商户，07：个人商户
        'businessLicense'=>'1000000000',                 //营业执照号码				非个人商户时必填
        'legalPersonName'=>'李某某',                       //法人姓名				个人用户请填写身份证姓名
        'legalPersonId'=>'420500198801018877',           //法人身份证				个人用户请填写身份证号
        'businessContact'=>'张某某',                       //联系人姓名
        'businessPhone'=>'13600000000',                   //联系人电话
        'settleMode'=>'1',                                  //结算类型，4为D0 ，1为T1
        'alipayCategory'=>'2016062900190116',             //支付宝经营类目
        'qqCategory'=>'Q000031',                            //QQ钱包经营类目
        'wechatCategory'=>'203',                             //微信经营类目
        'bankCard'=>'6226122111111111111',                 //银行卡号
        'bankLinked'=>'102100020794',                       //联行号
        'cardAccountType'=>'01',                            //卡账户类型 01 个人 02 企业
        'creditBankCard'=>'6222111111111111111',           //信用卡号
        'creditBankLinked'=>'102100020794',                  //信用卡联行号

        //拓展信息见文档中的拓展信息描述
        'extendParams'=>'1212{"03":[{"01":"11.11"}],"54":[{"01":"12.12"}],"00":[{"D0":"0.13"},{"T1":"0.14"},{"M0":"3"},{"M1":"4"}]}'
    );

    $request=new RequestHandler();
    $request->setGateURL(gateUrl);
    $request->setReqParams($input);
    $request->setKey(KEY);
    //发送请求参数
    $result=$request->call();

}

/**
 * 注意：
 * 1、提交被扫之后，返回系统繁忙、用户输入密码等错误信息时需要循环查单以确定是否支付成功
 * 2、多次（一半10次）确认都未明确成功时需要调用撤单接口撤单，防止用户重复支付
 */

?>
<body>  
	<form action="#" method="post">

        <div style="margin-left:2%;">机构号：</div><br/>
        <input type="text" style="width:96%;height:35px;margin-left:2%;" name="AGENT_MID" value="812017081524279" /><br /><br />
       	<div align="center">
			<input type="submit" value="提交报备" style="width:210px; height:50px; border-radius: 15px;background-color:#FE6714; border:0px #FE6714 solid; cursor: pointer;  color:white;  font-size:16px;" type="button" onclick="callpay()" />
		</div>
	</form>
</body>
</html>