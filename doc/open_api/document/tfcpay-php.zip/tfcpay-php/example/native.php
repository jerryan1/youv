<?php
/**
 * 微信/支付宝/QQ钱包扫码 示例
 * User: lihejia
 * Date: 2017/9
 */

require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * KEY：商户支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * notifyUrl：异步通知地址
 * @var string
 */
const MID="812017050323777";
const KEY="ddbax6n4cg8qj958ytt6";
const notifyUrl=TFCPayConfig::NOTIFY_URL;;
const gateUrl="https://devapi.tfcpay.com/v2/pay/paycode";

// 支付类型 wechat:微信 alipay:支付宝 QQwallet:QQ钱包
const type = "wechat";
//订单号
$orderNo = Util::getNonceStr();

//输入参数
$input=array( 'mid' => MID,
    'orderNo' => $orderNo,
    'subject' => 'round',
    'body'  => 'apple',
    'amount'=>"0.05",
    'type'=>type
);


$request=new RequestHandler();
$request->setGateURL(gateUrl);
$request->setReqParams($input);
$request->setKey(KEY);
//echo var_dump($request->debugInfo);
$result=$request->call();

//获取二维码
$qrcode=$result['qrCode']

?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>支付样例-扫码</title>
</head>
<body>
	<div style="margin-left: 10px;color:#556B2F;font-size:30px;font-weight: bolder;">扫码</div><br/>
	<img alt="扫码支付" src="qrcode.php?data=<?php echo urlencode($qrcode);?>" style="width:150px;height:150px;"/>

</body>
</html>
