<?php
/**
 * 网银支付示例
 * User: lihejia
 * Date: 2017/9
 */

require_once('../class/RequestHandler.class.php');
require_once('../class/PayHttpClient.class.php');
require_once ('../class/Util.php');
require_once ('../config/config.php');


/**
 * TODO: 修改这里配置为您自己申请的商户信息
 * MID：商户号（必须配置，开户邮件中可查看）
 * KEY：商户支付密钥，参考开户邮件设置
 * gateUrl:请求地址
 * notifyUrl：异步通知地址
 * @var string
 */
echo 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];

const MID="812017050323777";
const KEY="ddbax6n4cg8qj958ytt6";
const notifyUrl=TFCPayConfig::NOTIFY_URL;;
const gateUrl="https://devapi.tfcpay.com/v2/netpay";

// 支付类型 wechat:微信 alipay:支付宝 QQwallet:QQ钱包
const type = "wechat";
//订单号
$orderNo = Util::getNonceStr();
//输入参数
$input=array( 'mid' => MID,
    'orderNo' => $orderNo,
    'subject' => 'round',
    'body'  => 'apple',
    'amount'=>"0.10",
    'returnUrl'=>'',
    'bankCode'=>'105',
    'currencyType'=>"CNY",
    'cardType'=>'01',      //支付卡类型
    'channel'=>'',         //
    'businessType'=>'01',  //01（B2C-API）、02（B2C-收银台）、 03（B2B-API）、 04（B2B-收银台）、默认：01
    'remark'=>"这是个备注"
);

$request=new RequestHandler();
//设置请求地址
$request->setGateURL(gateUrl);
$request->setReqParams($input);
$request->setKey(KEY);

$request->isSign(false);  //设置不需验签

//echo var_dump($request->debugInfo);
$result=$request->call();

//直接返回的是form提交表单，会跳转到网银界面，到此接触

?>

<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>支付样例-网银支付</title>
</head>
<body>
<div style="margin-left: 10px;color:#556B2F;font-size:30px;font-weight: bolder;">网银支付</div><br/>
</body>
</html>
