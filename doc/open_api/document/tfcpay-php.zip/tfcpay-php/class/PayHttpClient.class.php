<?php

/**
 * http、https通信类
 * ============================================================================
 * api说明：
 * setReqContent($reqContent),设置请求内容，无论post和get，都用get方式提供
 * getResContent(), 获取应答内容
 * setMethod($method),设置请求方法,post或者get
 * getErrInfo(),获取错误信息
 * setCertInfo($certFile, $certPasswd, $certType="PEM"),设置证书，双向https时需要使用
 * setCaInfo($caFile), 设置CA，格式未pem，不设置则不检查
 * setTimeOut($timeOut)， 设置超时时间，单位秒
 * getResponseCode(), 取返回的http状态码
 * call(),真正调用接口
 * 
 * ============================================================================
 *
 */

class PayHttpClient {
	//请求内容，无论post和get，都用get方式提供
	var $reqContent = array();
	//应答内容
	var $resContent;
	
	//错误信息
	var $errInfo;
	
	//超时时间
	var $timeOut;
	
	//http状态码
	var $responseCode;
	
	function __construct() {
		$this->PayHttpClient();
	}
	
	
	function PayHttpClient() {
		$this->reqContent = "";
		$this->resContent = "";
		$this->errInfo = "";
		$this->timeOut = 30;
		$this->responseCode = 0;
		
	}
	
	//设置请求内容
	function setReqContent($url,$data) {
		$this->reqContent['url']=$url;
        $this->reqContent['data']=$data;
	}
	
	//获取结果内容
	function getResContent() {
		return $this->resContent;
	}
	
	//获取错误信息
	function getErrInfo() {
		return $this->errInfo;
	}
	
	//设置超时时间,单位秒
	function setTimeOut($timeOut) {
		$this->timeOut = $timeOut;
	}

    /***
     * @param $data
     * @param $url
     * @param bool $useCert
     * @param int $second
     * @return bool|string
     */
     function callPost($second = 30){

         $timeout=$this->timeOut;
         $url=$this->reqContent['url'];
         $data=$this->reqContent['data'];
         $postdata = http_build_query(
            $data
         );

        $opts = array('http' =>
            array(
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => $postdata
            )
        );

          $context = stream_context_create($opts);
         $res = file_get_contents($url, false, $context);

         //返回结果
         if ($res == NULL) {
             return false;
         }
         $this->resContent = $res;

         return true;
    }

	
	//执行http调用
	function call() {

	    $timeout=$this->timeOut;
	    $url=$this->reqContent['url'];
	    $data=$this->reqContent['data'];

        $ch = curl_init();
        //设置超时
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

        curl_setopt($ch,CURLOPT_URL, $url);

        if(stripos($url,"https://")!==FALSE){
            curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        }
        else    {
            curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,TRUE);
            curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,2);//严格校验
        }
        //设置header
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        //要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

        //post提交方式
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        //运行curl
        $res = curl_exec($ch);
        echo var_dump($res);

        //返回结果
        if ($res == NULL) {
            $this->errInfo = "call http err :" . curl_errno($ch) . " - " . curl_error($ch) ;
            curl_close($ch);
            return false;
        } else if($this->responseCode  != "200") {
            $this->errInfo = "call http err httpcode=" . $this->responseCode  ;
            curl_close($ch);
            return false;
        }

        curl_close($ch);
        $this->resContent = $res;

        return true;


	}
	
	function getResponseCode() {
		return $this->responseCode;
	}
	
}
?>