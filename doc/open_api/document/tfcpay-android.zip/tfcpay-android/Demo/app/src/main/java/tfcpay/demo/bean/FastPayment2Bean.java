package tfcpay.demo.bean;

/**
 * Created by a on 2017/8/15.
 */

public class FastPayment2Bean {

    /**
     * code : SUCCESS
     * flowNo : ZF20170922142810573922
     * html : <html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/></head><body><form id = "pay_form" action="https://gateway.95516.com/gateway/api/frontTransReq.do" method="post" accept-charset="UTF-8"><input type="hidden" name="channelType" id="channelType" value="07"/><input type="hidden" name="acqInsCode" id="acqInsCode" value="48533320"/><input type="hidden" name="txnSubType" id="txnSubType" value="01"/><input type="hidden" name="version" id="version" value="5.0.0"/><input type="hidden" name="txnAmt" id="txnAmt" value="10000"/><input type="hidden" name="signMethod" id="signMethod" value="01"/><input type="hidden" name="backUrl" id="backUrl" value="https://payment.handpay.cn/hpayTransGatewayWeb/b2cNotify/bankAsynNotify.htm"/><input type="hidden" name="merAbbr" id="merAbbr" value="在线易付费"/><input type="hidden" name="securityType" id="securityType" value="01"/><input type="hidden" name="encoding" id="encoding" value="UTF-8"/><input type="hidden" name="merCatCode" id="merCatCode" value="4900"/><input type="hidden" name="encryptCertId" id="encryptCertId" value="69374126198"/><input type="hidden" name="orderId" id="orderId" value="544882783"/><input type="hidden" name="signature" id="signature" value="L/Dtun7mbR7ItBo0Ne4pZVcmUQ2OPzcFGGXxqzh3c0LUfVYLwxajNM81x6EUlm26MidIyqWhkfM8HTPlm+qtlnorAf+vRMVQRBqHui8X0OjOOnK7Xww9JMtpg+b28lCn0MQQulRCgu8QLDVg5FHNtM67AU02zxQZYisrFMSuNbwpHzAl2c1N1p4duHqPvJf/221N4n2cuSEbv1j4DSKH/faOMWUntdRKk4m5pgujmYJZ7t53tr1O8NWri2rAOh7xgNtHg18jgjSQ9pQltZKSMIGYhR9VvmgZMXV4nTGEIz/VLBBlsQaWxiSsGJilobS5mwKPDAbw80XuxvA7wFjsCg=="/><input type="hidden" name="txnType" id="txnType" value="01"/><input type="hidden" name="frontUrl" id="frontUrl" value="https://payment.handpay.cn/hpayTransGatewayWeb/b2cNotify/bankNotify.htm"/><input type="hidden" name="currencyCode" id="currencyCode" value="156"/><input type="hidden" name="merId" id="merId" value="853290049005613"/><input type="hidden" name="reserved" id="reserved" value="{cardNumberLock=1}"/><input type="hidden" name="accNo" id="accNo" value="6225758342665071"/><input type="hidden" name="certId" id="certId" value="69374126198"/><input type="hidden" name="merName" id="merName" value="在线易付费"/><input type="hidden" name="bizType" id="bizType" value="000201"/><input type="hidden" name="orderTimeout" id="orderTimeout" value="7200000"/><input type="hidden" name="accessType" id="accessType" value="1"/><input type="hidden" name="txnTime" id="txnTime" value="20170922142812"/></form></body><script type="text/javascript">document.all.pay_form.submit();</script></html>
     * mid : 822017092124477
     * msg : 下单成功
     * noise : m4TwXt5OmK9kZtSLNKUebxL2clzbi9NZ
     * orderNo : 5455454545
     * resultCode : SUCCESS
     * sign : AE89EDA3003094F6CF7B53379F8E3E56
     */

    private String code;
    private String flowNo;
    private String html;
    private String mid;
    private String msg;
    private String noise;
    private String orderNo;
    private String resultCode;
    private String sign;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getFlowNo() {
        return flowNo;
    }

    public void setFlowNo(String flowNo) {
        this.flowNo = flowNo;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getNoise() {
        return noise;
    }

    public void setNoise(String noise) {
        this.noise = noise;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
