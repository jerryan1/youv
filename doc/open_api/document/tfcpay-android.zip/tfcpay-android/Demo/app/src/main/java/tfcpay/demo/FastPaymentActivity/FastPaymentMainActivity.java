package tfcpay.demo.FastPaymentActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.unionpay.UPPayAssistEx;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tfcpay.demo.R;
import tfcpay.demo.adapter.ListViewAdapter;
import tfcpay.demo.bean.FastPaymentBean;
import tfcpay.demo.bean.FastPaymentResultCodeBean;
import tfcpay.demo.bean.ListBean;
import tfcpay.demo.utils.GsonUtils;
import tfcpay.demo.utils.RanDomStringUtils;
import tfcpay.demo.utils.SPUtils;
import tfcpay.demo.utils.SignatureUtils;
import tfcpay.demo.utils.TimeUtils;
import tfcpay.demo.utils.ToastUtils;
import tfcpay.demo.utils.UtilsPost;

public class FastPaymentMainActivity extends AppCompatActivity {


    private List<ListBean> mListBeanList;
    private int mIntx;
    private FastPaymentBean mShBean;
    private Bundle mExtras;
    private SPUtils mSpUtils;
    private String noise;
    private EditText mEd_mid, mEd_notifyUrl, mEd_orderNo, mEd_subject, mEd_body, mEd_amount,
            mEd_bankCardNo, mEd_feeRate, mEd_mustAmt, mEd_receivedCardNo, mEd_receivedPhoneNo, mEd_receivedCardId, mEd_receivedRealName, mEd_remark, mEd_miyao;
    private TextView mEd_receivedBankCod;
    private String mEncode;
    private Button mBu_tj;
    private String mGenre;
    private String mMode = "00";
    private EditText mEt_url_lujing;
    private String mTime;
    private FastPaymentMainActivity mActivity;
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    //支付
                    gopayment();
                    break;
                case 3:
                    ToastUtils.getToastUtils(mActivity, "请重新选择您的环境", 0);
                    mBu_tj.setClickable(true);
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private TextView mId_tv_pop;
    private EditText mEd_cardType;
    private FastPaymentResultCodeBean mFastPaymentResultCodeBean;
    private String[] mData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_fast_payment_main);
        mActivity = FastPaymentMainActivity.this;
        mSpUtils = new SPUtils(mActivity, "SaveData");
        noise = RanDomStringUtils.getRandomString();  //随机16位字符串
        mTime = TimeUtils.getTime(); //获取本地时间生成时间戳
        initListData();//添加数据
        initView();//初始化view
    }

    /**
     * initListData
     * 添加银行和编码
     */
    private void initListData() {
        mListBeanList = new ArrayList<>();
        mListBeanList.add(new ListBean("中国银行", "104"));
        mListBeanList.add(new ListBean("中信银行", "106"));
        mListBeanList.add(new ListBean("兴业银行", "309"));
        mListBeanList.add(new ListBean("招商银行", "310"));
        mListBeanList.add(new ListBean("光大银行", "330"));
        mListBeanList.add(new ListBean("平安银行", "340"));
        mListBeanList.add(new ListBean("交通银行", "350"));
        mListBeanList.add(new ListBean("民生银行", "360"));
        mListBeanList.add(new ListBean("北京银行", "370"));
        mListBeanList.add(new ListBean("华夏银行", "380"));
        mListBeanList.add(new ListBean("南京银行", "390"));
        mListBeanList.add(new ListBean("东亚银行", "400"));
        mListBeanList.add(new ListBean("浦发银行", "410"));
        mListBeanList.add(new ListBean("上海银行", "420"));
        mListBeanList.add(new ListBean("兰州银行", "430"));
        mListBeanList.add(new ListBean("徽商银行", "440"));
        mListBeanList.add(new ListBean("青岛银行", "450"));
        mListBeanList.add(new ListBean("浙商银行", "460"));
        mListBeanList.add(new ListBean("国家开发银行", "470"));
        mListBeanList.add(new ListBean("广东发展银行", "500"));
        mListBeanList.add(new ListBean("中国工商银行", "102"));
        mListBeanList.add(new ListBean("中国农业银行", "103"));
        mListBeanList.add(new ListBean("中国建设银行", "105"));
        mListBeanList.add(new ListBean("中国进出口银行", "480"));
        mListBeanList.add(new ListBean("中国邮政储蓄银行", "403"));
        mListBeanList.add(new ListBean("中国农业发展银行", "490"));
        mListBeanList.add(new ListBean("渤海银行股份有限公司", "510"));
    }

    /**
     * gopayment
     * 判断code是否成功，成功进入调用SDK
     */
    private void gopayment() {
        if (mShBean.getCode().equals("SUCCESS")) {

            if (mShBean.getResultCode().equals("SUCCESS")) {
                //保存数据
                saveData();
                //发送请求sdk
                UPPayAssistEx.startPay(mActivity, null, null, mShBean.getTokenId(), mMode);
            } else {
                //提示用户错误信息
                ToastUtils.getToastUtils(mActivity, mFastPaymentResultCodeBean.getErrCodeDes(), 0);
                mBu_tj.setClickable(true);
            }

        } else {
            //提示用户错误信息
            ToastUtils.getToastUtils(mActivity, mShBean.getMsg(), 0);
            mBu_tj.setClickable(true);
        }
    }

    /**
     * saveData
     * 保存输入的数据
     */
    private void saveData() {
        mSpUtils.putString("et_url_lujing", mEt_url_lujing.getText().toString().trim());
        mSpUtils.putString("mid", mEd_mid.getText().toString().trim());
        mSpUtils.putString("mEd_notifyUrl", mEd_notifyUrl.getText().toString().trim());
        mSpUtils.putString("mEd_subject", mEd_subject.getText().toString().trim());
        mSpUtils.putString("mEd_body", mEd_body.getText().toString().trim());
        mSpUtils.putString("mEd_amount", mEd_amount.getText().toString().trim());
        mSpUtils.putString("mEd_bankCardNo", mEd_bankCardNo.getText().toString().trim());
        mSpUtils.putString("mEd_feeRate", mEd_feeRate.getText().toString().trim());
        mSpUtils.putString("mEd_mustAmt", mEd_mustAmt.getText().toString().trim());
        mSpUtils.putString("mEd_receivedCardNo", mEd_receivedCardNo.getText().toString().trim());
        mSpUtils.putString("mEd_receivedPhoneNo", mEd_receivedPhoneNo.getText().toString().trim());
        mSpUtils.putString("mEd_receivedCardId", mEd_receivedCardId.getText().toString().trim());
        mSpUtils.putString("mEd_receivedRealName", mEd_receivedRealName.getText().toString().trim());
        mSpUtils.putString("mEd_remark", mEd_remark.getText().toString().trim());
        mSpUtils.putString("mEd_miyao", mEd_miyao.getText().toString().trim());
    }

    /**
     * initView
     * 初始化view
     */
    private void initView() {
        mId_tv_pop = (TextView) findViewById(R.id.id_tv_pop);
        mId_tv_pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popUrl();
            }
        });
        mEt_url_lujing = (EditText) findViewById(R.id.et_url_lujing);
        //第一次输入正确的信息之后会保存到SP
        mEt_url_lujing.setText(mSpUtils.getString("et_url_lujing"));
        mEd_mid = (EditText) findViewById(R.id.ed_mid);
        mEd_mid.setText(mSpUtils.getString("mid"));
        mEd_notifyUrl = (EditText) findViewById(R.id.ed_notifyUrl);
        mEd_notifyUrl.setText(mSpUtils.getString("mEd_notifyUrl"));
        mEd_orderNo = (EditText) findViewById(R.id.ed_orderNo);
        mEd_orderNo.setText(mTime);
        mEd_subject = (EditText) findViewById(R.id.ed_subject);
        mEd_subject.setText(mSpUtils.getString("mEd_subject"));
        mEd_body = (EditText) findViewById(R.id.ed_body);
        mEd_body.setText(mSpUtils.getString("mEd_body"));
        mEd_amount = (EditText) findViewById(R.id.ed_amount);
        mEd_amount.setText(mSpUtils.getString("mEd_amount"));
        mEd_bankCardNo = (EditText) findViewById(R.id.ed_bankCardNo);
        mEd_bankCardNo.setText(mSpUtils.getString("mEd_bankCardNo"));
        mEd_miyao = (EditText) findViewById(R.id.ed_miyao);
        mEd_miyao.setText(mSpUtils.getString("mEd_miyao"));
        mEd_feeRate = (EditText) findViewById(R.id.ed_feeRate);
        mEd_feeRate.setText(mSpUtils.getString("mEd_feeRate"));
        mEd_mustAmt = (EditText) findViewById(R.id.ed_mustAmt);
        mEd_mustAmt.setText(mSpUtils.getString("mEd_mustAmt"));
        mEd_remark = (EditText) findViewById(R.id.ed_remark);
        mEd_remark.setText(mSpUtils.getString("mEd_remark"));
        mEd_cardType = (EditText) findViewById(R.id.ed_cardType);
        mEd_receivedCardNo = (EditText) findViewById(R.id.ed_receivedCardNo);
        mEd_receivedCardNo.setText(mSpUtils.getString("mEd_receivedCardNo"));
        mEd_receivedPhoneNo = (EditText) findViewById(R.id.ed_receivedPhoneNo);
        mEd_receivedPhoneNo.setText(mSpUtils.getString("mEd_receivedPhoneNo"));
        mEd_receivedCardId = (EditText) findViewById(R.id.ed_receivedCardId);
        mEd_receivedCardId.setText(mSpUtils.getString("mEd_receivedCardId"));
        mEd_receivedRealName = (EditText) findViewById(R.id.ed_receivedRealName);
        mEd_receivedRealName.setText(mSpUtils.getString("mEd_receivedRealName"));
        mEd_receivedBankCod = (TextView) findViewById(R.id.ed_receivedBankCode);
        mBu_tj = (Button) findViewById(R.id.btt_tj);

        mBu_tj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //判断不能为空
                check();
                mBu_tj.setClickable(false);
            }
        });
        mEd_receivedBankCod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //选择编码
                popCoding();
            }
        });
    }

    /**
     * popUrl
     * 选择请求地址
     */
    private void popUrl() {

        final List<ListBean> popUrlData = new ArrayList<>();
        popUrlData.add(new ListBean("准生产环境", "https://zdevapi.tfcpay.com/v2/quickPay/mobilePay"));
        popUrlData.add(new ListBean("准生产测试环境合伙人", "http://172.16.102.15:8082/quickPay/mobilePay"));
        popUrlData.add(new ListBean("生产测试环境", "https://api.tfcpay.com/v2/quickPay/mobilePay"));
        popUrlData.add(new ListBean("生产测试环境合伙人", "http://203.81.244.127/v2/quickPay/mobilepay"));
        popUrlData.add(new ListBean("商户测试环境", "https://devapi.tfcpay.com/v2/quickPay/mobilePay"));
        popUrlData.add(new ListBean("测试环境", "http://192.168.9.121/v2/quickPay/mobilePay"));
        popUrlData.add(new ListBean("测试环境合伙人", "http://192.168.9.81/v2/quickPay/mobilePay"));
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        //以上是添加数据
        final AlertDialog dialog = builder.create();
        View popcoding = View.inflate(mActivity, R.layout.listview_layout, null);
        dialog.setView(popcoding);
        dialog.setTitle("请您选择请求地址或者自行输入");
        ListView lv = (ListView) popcoding.findViewById(R.id.lv_xml);
        ListViewAdapter adapter = new ListViewAdapter(mActivity, popUrlData);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mEt_url_lujing.setText(popUrlData.get(i).getId());
                dialog.dismiss();
            }
        });
        dialog.show();
        //设置窗口的大小
        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = ActionBar.LayoutParams.MATCH_PARENT;
        params.height = ActionBar.LayoutParams.WRAP_CONTENT;
        dialog.getWindow().setAttributes(params);

    }

    /**
     * popCoding
     * 选择银行附带id为银行编码
     */
    private void popCoding() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        final AlertDialog dialog = builder.create();
        View popcoding = View.inflate(mActivity, R.layout.listview_layout, null);
        dialog.setView(popcoding);
        dialog.setTitle("请您选择银行");
        ListView lv = (ListView) popcoding.findViewById(R.id.lv_xml);
        ListViewAdapter adapter = new ListViewAdapter(mActivity, mListBeanList);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mEd_receivedBankCod.setText(mListBeanList.get(i).getName());
                mIntx = i;
                dialog.dismiss();
            }
        });
        dialog.show();
        WindowManager wm1 = this.getWindowManager();
        int height = wm1.getDefaultDisplay().getHeight() / 2;
        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = ActionBar.LayoutParams.MATCH_PARENT;
        params.height = height;
        dialog.getWindow().setAttributes(params);
    }

    /**
     * check
     * 判断每个输入项不能为空
     */
    private void check() {
        if (TextUtils.isEmpty(mEt_url_lujing.getText())) {
            ToastUtils.getToastUtils(mActivity, "请求地址不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_mid.getText())) {
            ToastUtils.getToastUtils(mActivity, "商户名不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_notifyUrl.getText())) {
            ToastUtils.getToastUtils(mActivity, "通知URL不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_orderNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "订单号不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_subject.getText())) {
            ToastUtils.getToastUtils(mActivity, "商品名称不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_body.getText())) {
            ToastUtils.getToastUtils(mActivity, "商品描述不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_amount.getText())) {
            ToastUtils.getToastUtils(mActivity, "交易金额不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_mustAmt.getText())) {
            ToastUtils.getToastUtils(mActivity, "固定金额不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_feeRate.getText())) {
            ToastUtils.getToastUtils(mActivity, "交易费率不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_bankCardNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "付款人银行卡不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_receivedRealName.getText())) {
            ToastUtils.getToastUtils(mActivity, "收款人姓名不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_receivedPhoneNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "收款人手机号不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_receivedCardNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "收款人银行卡不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_receivedCardId.getText())) {
            ToastUtils.getToastUtils(mActivity, "收款人身份证不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_receivedBankCod.getText())) {
            ToastUtils.getToastUtils(mActivity, "收款人银行不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_miyao.getText())) {
            ToastUtils.getToastUtils(mActivity, "秘钥不能为空", 0);
            return;
        }
        initData();

    }

    /**
     * initData
     * 字段以数组的形式进行封装
     */
    private void initData() {
        if (!TextUtils.isEmpty(mEd_remark.getText())) {
            mData = new String[]{"mid=" + mEd_mid.getText().toString().trim(),
                    "subject=" + mEd_subject.getText().toString().trim(),
                    "notifyUrl=" + mEd_notifyUrl.getText().toString().trim(),
                    "orderNo=" + mEd_orderNo.getText().toString().trim(),
                    "body=" + mEd_body.getText().toString().trim(),
                    "amount=" + mEd_amount.getText().toString().trim(),
                    "bankCardNo=" + mEd_bankCardNo.getText().toString().trim(),
                    "feeRate=" + mEd_feeRate.getText().toString().trim(),
                    "mustAmt=" + mEd_mustAmt.getText().toString().trim(),
                    "cardType=02",
                    "receivedCardNo=" + mEd_receivedCardNo.getText().toString().trim(),
                    "receivedCardId=" + mEd_receivedCardId.getText().toString().trim(),
                    "remark=" + mEd_remark.getText().toString().trim(),
                    "receivedPhoneNo=" + mEd_receivedPhoneNo.getText().toString().trim(),
                    "receivedBankCode=" + mListBeanList.get(mIntx).getId(),
                    "receivedRealName=" + mEd_receivedRealName.getText().toString().trim(),
                    "noise=" + noise
            };
        } else {
            mData = new String[]{"mid=" + mEd_mid.getText().toString().trim(),
                    "subject=" + mEd_subject.getText().toString().trim(),
                    "notifyUrl=" + mEd_notifyUrl.getText().toString().trim(),
                    "orderNo=" + mEd_orderNo.getText().toString().trim(),
                    "body=" + mEd_body.getText().toString().trim(),
                    "amount=" + mEd_amount.getText().toString().trim(),
                    "bankCardNo=" + mEd_bankCardNo.getText().toString().trim(),
                    "feeRate=" + mEd_feeRate.getText().toString().trim(),
                    "mustAmt=" + mEd_mustAmt.getText().toString().trim(),
                    "cardType=02",
                    "receivedCardNo=" + mEd_receivedCardNo.getText().toString().trim(),
                    "receivedCardId=" + mEd_receivedCardId.getText().toString().trim(),
                    "receivedPhoneNo=" + mEd_receivedPhoneNo.getText().toString().trim(),
                    "receivedBankCode=" + mListBeanList.get(mIntx).getId(),
                    "receivedRealName=" + mEd_receivedRealName.getText().toString().trim(),
                    "noise=" + noise
            };
        }
        String miyao = mEd_miyao.getText().toString().trim();
        //生成的签名
        mEncode = SignatureUtils.initSort(mData, miyao);
        if (mEncode != null) {//签名不为空执行请求
            startThread();
        }
    }

    /**
     * startThread
     * 开启子线程请求服务器
     */
    private void startThread() {
        new Thread() {
            @Override
            public void run() {
                Map<String, Object> map = new HashMap<>();
                map.put("mid", mEd_mid.getText().toString().trim());                                //商户号
                map.put("notifyUrl", mEd_notifyUrl.getText().toString().trim());                    //针对该交易的交易状态同步通知接受URL(如不填写,则收不到通知)
                map.put("orderNo", mEd_orderNo.getText().toString().trim());                        //合作伙伴交易号（确保在合作伙伴系统中唯一）
                map.put("subject", mEd_subject.getText().toString().trim());                        //商品的标题
                map.put("body", mEd_body.getText().toString().trim());                              //商品的具体描述
                map.put("amount", mEd_amount.getText().toString().trim());                          //交易的总金额，单位为元
                map.put("bankCardNo", mEd_bankCardNo.getText().toString().trim());                  //交易的总金额，单位为元
                map.put("feeRate", mEd_feeRate.getText().toString().trim());                        //交易的总金额，单位为元
                map.put("mustAmt", mEd_mustAmt.getText().toString().trim());                        //固定金额
                map.put("cardType", "02");                                                           //02（信用卡） 默认是信用卡
                map.put("receivedCardNo", mEd_receivedCardNo.getText().toString().trim());          //收款方银行卡号
                map.put("receivedCardId", mEd_receivedCardId.getText().toString().trim());          //收款方银行卡号
                map.put("receivedPhoneNo", mEd_receivedPhoneNo.getText().toString().trim());        //收款方手机号码
                map.put("receivedBankCode", mListBeanList.get(mIntx).getId());                      //收款方银行编码
                map.put("receivedRealName", mEd_receivedRealName.getText().toString().trim());      //收款方银行卡开户名
                if (!TextUtils.isEmpty(mEd_remark.getText())) {
                    map.put("remark", mEd_remark.getText().toString().trim());                       //备注
                }
                map.put("noise", noise);                                                            //随机字符串要求不超过32位，本dome以16位为基础
                map.put("sign", mEncode);                                                           //数据的加密校验字符串，目前只支持使用MD5签名算法对待签名数据进行签名
                String result = UtilsPost.postUrlConnect(mEt_url_lujing.getText().toString().trim(), map);
                if (result != null) {
                    Log.i("result", result + "---成功");
                    mShBean = GsonUtils.toGlass(result, FastPaymentBean.class);
                    mFastPaymentResultCodeBean = GsonUtils.toGlass(result, FastPaymentResultCodeBean.class);
                    //发送消息刷新UI
                    Message message = new Message();
                    message.what = 1;
                    mHandler.sendMessage(message);
                } else {
                    Log.i("result", "失败");
                    Message message = new Message();
                    message.what = 3;
                    mHandler.sendMessage(message);
                }

            }
        }.start();
    }

    /**
     * @param requestCode
     * @param resultCode
     * @param data        异步通知返回的结果
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {
            return;
        }
        String msg = "";
        /*
         * 支付控件返回字符串:success、fail、cancel 分别代表支付成功，支付失败，支付取消
         */
        String str = data.getExtras().getString("pay_result");
        if (str.equalsIgnoreCase("success")) {

            // 如果想对结果数据验签，可使用下面这段代码，但建议不验签，直接去商户后台查询交易结果
            // result_data结构见c）result_data参数说明
            if (data.hasExtra("result_data")) {
                String result = data.getExtras().getString("result_data");
                try {
                    JSONObject resultJson = new JSONObject(result);
                    String sign = resultJson.getString("sign");
                    String dataOrg = resultJson.getString("data");
                    // 此处的verify建议送去商户后台做验签
                    // 如要放在手机端验，则代码必须支持更新证书
                    boolean ret = verify(dataOrg, sign, mExtras.getString("mode"));
                    if (ret) {
                        // 验签成功，显示支付结果
                        msg = "支付成功！";
                    } else {
                        // 验签失败
                        msg = "支付失败！";
                    }
                } catch (JSONException e) {
                }
            }
            // 结果result_data为成功时，去商户后台查询一下再展示成功
            msg = "支付成功！";
        } else if (str.equalsIgnoreCase("fail")) {
            msg = "支付失败！";
        } else if (str.equalsIgnoreCase("cancel")) {
            onResume();
            msg = "用户取消了支付";

        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("支付结果通知");
        builder.setMessage(msg);
        builder.setInverseBackgroundForced(true);
        // builder.setCustomTitle();
        builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                onResume();
                dialog.dismiss();
            }
        });
        builder.create().show();
    }


    /**
     * 此处的verify，商户需送去商户后台做验签
     */
    private boolean verify(String msg, String sign64, String mode) {
        // 此处的verify，商户需送去商户后台做验签
        return true;

    }

    /**
     * onRestart
     * 利用android生命周期,刷新订单号
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        mTime = TimeUtils.getTime(); //获取本地时间生成时间戳
        mEd_orderNo.setText(mTime);
        mBu_tj.setClickable(true);
    }

}
