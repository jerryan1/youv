package tfcpay.demo.FastPayment2Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import tfcpay.demo.R;


/**
 * WebViewActivity
 * 本页面主要以加载显示 html
 */
public class WebViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_web_view);
        //获取参数
        String html = getIntent().getExtras().getString("html");
        initViewData(html);
    }

    /**
     * initViewData
     * 初始化view 加载html
     * @param html  在首页获取传到本页面来
     */
    private void initViewData(String html) {
        WebView web = (WebView) findViewById(R.id.web);
        //启用支持javascript
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient());
        //加载web页面
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);

    }
}
