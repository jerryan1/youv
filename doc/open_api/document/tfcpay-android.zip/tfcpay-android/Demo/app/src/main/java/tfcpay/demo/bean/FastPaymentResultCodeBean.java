package tfcpay.demo.bean;

/**
 * Created by a on 2017/9/26.
 */

public class FastPaymentResultCodeBean {

    /**
     * code : SUCCESS
     * errCode : ORDER_EXIST
     * errCodeDes : 订单已存在
     * mid : 822017071423867
     * noise : jFKaAVRz7W5NZLnMAFSXaZ1J91uqaEyL
     * resultCode : ERROR
     * sign : B03850DD2A340120654D144463DDB5EA
     */

    private String code;
    private String errCode;
    private String errCodeDes;
    private String mid;
    private String noise;
    private String resultCode;
    private String sign;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getErrCodeDes() {
        return errCodeDes;
    }

    public void setErrCodeDes(String errCodeDes) {
        this.errCodeDes = errCodeDes;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getNoise() {
        return noise;
    }

    public void setNoise(String noise) {
        this.noise = noise;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
