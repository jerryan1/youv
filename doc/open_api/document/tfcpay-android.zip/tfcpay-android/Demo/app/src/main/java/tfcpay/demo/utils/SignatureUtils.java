package tfcpay.demo.utils;

import android.util.Log;

import java.util.Arrays;

/**
 *  SignatureUtils
 *  此方法主要是生成签名,执行顺序是  Arrays.sort自然排序- StringBuilder拼接字符串-
 *      new String(stingdata.getBytes("UTF-8"), "UTF-8")转码-MD5Encode.encode(codingData)MD5加密-
 *      toUpperCase()转大写
 *   此顺序不能变,负责提示 "验签错误"
 */

public class SignatureUtils {
    /**
     *
     * @param data  拿到数据源进行自然排序
     * @param miyao
     * @return       返回结果
     */
    public static  String initSort(String[] data,String miyao) {
        String Signature = null;
        try {
            //自然排序
            Arrays.sort(data);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < data.length; i++) {
                sb.append(data[i] + "&");
            }
            //拼接字符串
            String stingdata = sb.toString() + miyao;
            Log.i("验签",stingdata+"");
            //转码
            String codingData = new String(stingdata.getBytes("UTF-8"), "UTF-8");
            //MD5加密- 转大写
            String encode = MD5Encode.encode(codingData);
            Signature = encode.toUpperCase();

        } catch (Exception e) {
            e.printStackTrace();
        }
        //返回结果
        return Signature;
    }


}
