package tfcpay.demo.utils;

import android.util.Log;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/**
 * Created by a on 2017/8/11.
 */

public class UtilsPost {
    //post请求
    public static String postUrlConnect(String urlPath, Map<String, Object> map) {
        StringBuffer sbRequest = new StringBuffer();
        if (map != null && map.size() > 0) {
            for (String key : map.keySet()) {
                sbRequest.append(key + "=" + map.get(key) + "&");
            }
        }
        String request = sbRequest.substring(0, sbRequest.length() - 1);
        try {
            //创建URL
            URL url = new URL(urlPath);
            Log.i("---",url+""+request);
            HttpURLConnection httpURLConnection =
                    (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setConnectTimeout(30000);
            httpURLConnection.setReadTimeout(30000);
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);
            OutputStream os = httpURLConnection.getOutputStream();
            os.write(request.getBytes());
            os.flush();
            if (httpURLConnection.getResponseCode() == 200) {
                InputStream in = httpURLConnection.getInputStream();
                StringBuffer sb = new StringBuffer();
                byte[] buff = new byte[1024];
                int len = -1;
                while ((len = in.read(buff)) != -1) {
                    sb.append(new String(buff, 0, len, "utf-8"));
                }
                in.close();
                os.close();
                httpURLConnection.disconnect();
                return sb.toString();
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }
}
