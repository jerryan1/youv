package tfcpay.demo.utils;

import com.google.gson.Gson;

/**
 * Created by a on 2017/8/4.
 */

public class GsonUtils {
    public  static Gson sGson;
    public  static  <T> T toGlass(String json, Class<T> cls){
        if (sGson==null){
            sGson=new Gson();
        }
        return  sGson.fromJson(json,cls);
    }
}
