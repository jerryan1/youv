package tfcpay.demo.utils;

/**
 * Created by a on 2017/9/27.
 */

public class CommUtils {
    private static long lastClickTime;

    /**
     * 处理按钮被连续点击的问题。
     *
     * @param ms
     *            毫秒
     * @return boolean 是否在这段时间内连续点击
     * */
    public static boolean isFastDoubleClick(int ms) {
        long time = System.currentTimeMillis();
        long timeD = time - lastClickTime;
        if (0 < timeD && timeD < ms) {
            return true;
        }
        lastClickTime = time;
        return false;
    }
}
