package tfcpay.demo.bean;

/**
 * Created by a on 2017/8/15.
 */

public class FastPaymentBean {


    /**
     * code : SUCCESS
     * flowNo : 0926161906336859
     * mid : 822017071423867
     * msg : 下单成功
     * noise : WAHEl1Czil3zgwMn4gVlDfVY7g4nhCqB
     * orderNo : 20170926041901
     * resultCode : SUCCESS
     * sign : 7D3A54AFEDDF8A167BF3A6B2639B571A
     * tokenId : 853601236314185073103
     */

    private String code;
    private String flowNo;
    private String mid;
    private String msg;
    private String noise;
    private String orderNo;
    private String resultCode;
    private String sign;
    private String tokenId;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getFlowNo() {
        return flowNo;
    }

    public void setFlowNo(String flowNo) {
        this.flowNo = flowNo;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getNoise() {
        return noise;
    }

    public void setNoise(String noise) {
        this.noise = noise;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }
}
