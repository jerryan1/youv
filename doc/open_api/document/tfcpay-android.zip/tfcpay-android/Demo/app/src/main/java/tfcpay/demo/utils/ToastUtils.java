package tfcpay.demo.utils;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

import static android.widget.Toast.makeText;

/**
 * Created by a on 2017/8/18.
 */

public class ToastUtils {
    private static Toast sToast;
    public  static void getToastUtils(Context context, String content, int  i){
        if (i==0){
            sToast =makeText(context, content, Toast.LENGTH_SHORT);
        }else{
            sToast =makeText(context, content, Toast.LENGTH_LONG);
        }
        sToast.setGravity(Gravity.CENTER, 0, 0);
        sToast.show();
    }
}
