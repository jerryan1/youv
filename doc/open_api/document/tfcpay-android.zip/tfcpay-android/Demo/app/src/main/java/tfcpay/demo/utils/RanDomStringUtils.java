package tfcpay.demo.utils;

import java.util.Random;

/**
 * Created by a on 2017/9/26.
 */

public class RanDomStringUtils {
    /**
     * getRandomString
     * 随机字符串
     *
     * @return 返回生成的字符串
     */
    public   static String getRandomString() {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 16; i++) {
            int number = random.nextInt(52);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }
}
