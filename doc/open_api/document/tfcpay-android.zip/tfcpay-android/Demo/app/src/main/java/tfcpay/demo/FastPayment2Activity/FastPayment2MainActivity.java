package tfcpay.demo.FastPayment2Activity;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tfcpay.demo.R;
import tfcpay.demo.adapter.ListViewAdapter;
import tfcpay.demo.bean.FastPayment2Bean;
import tfcpay.demo.bean.FastPayment2ResultCodeBean;
import tfcpay.demo.bean.ListBean;
import tfcpay.demo.utils.GsonUtils;
import tfcpay.demo.utils.RanDomStringUtils;
import tfcpay.demo.utils.SPUtils;
import tfcpay.demo.utils.SignatureUtils;
import tfcpay.demo.utils.TimeUtils;
import tfcpay.demo.utils.ToastUtils;
import tfcpay.demo.utils.UtilsPost;

/**
 * FastPayment2MainActivity
 * 以用户填入信息，进行验签，生成签名，请求服务器拿到字段“html”，
 * 并进入web页面加载“html”，展示效过、支付等。
 */
public class FastPayment2MainActivity extends AppCompatActivity {

    private List<ListBean> mListBeanList;
    private FastPayment2MainActivity mActivity;
    private int mIntx;

    private EditText mEd_mid;
    private EditText mEd_notifyUrl;
    private EditText mEd_orderNo;
    private EditText mEd_amount;
    private EditText mEd_subject;
    private EditText mEd_body;
    private EditText mEd_bankCardNo;
    private EditText mEd_cardId;
    private EditText mEd_phoneNo;
    private TextView mEd_bankCode;
    private EditText mEd_remark;
    private EditText mEd_miyao;
    private Button mBtt_tj;
    private String noise;
    private FastPayment2Bean mShBean;
   // private String url = "http://192.168.5.203:8080/leopard-netpay-web/quickPay/quickPayB2c";//以最新聚融通在线文档为准
     private  String url="http://192.168.9.121/v2/quickPay/quickPayB2c"; //测试  以最新聚融通在线文档为准
    private SPUtils mSpUtils;
    /**
     * mHandler
     * 使用handler刷新UI
     * what==1 去支付
     * what==3 出现了问题需要解决
     */
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    //支付
                    gopayment();
                    break;
                case 3:
                    //提醒开发者，网络没有请求到或者超时
                    ToastUtils.getToastUtils(mActivity, "请编程看看怎么回事", 0);
                    mBtt_tj.setClickable(true);
                    break;
            }
            super.handleMessage(msg);
        }
    };
    private String mTime;
    private FastPayment2ResultCodeBean mFastPayment2ResultCodeBean;
    private String[] mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_fastpaymentmainactivity);
        mActivity = FastPayment2MainActivity.this;
        //保存数据
        mSpUtils = new SPUtils(mActivity, "FastPayment2Data");
        //获取本地时间生成时间戳
        mTime = TimeUtils.getTime();
        //初始化数据
        initListData();
        //随机16位字符串
        noise = RanDomStringUtils.getRandomString();
        //初始化view
        initView();
    }

    //保存数据

    /**
     * saveData
     * 保存输入的信息
     */
    private void saveData() {
        mSpUtils.putString("mid", mEd_mid.getText().toString().trim());
        mSpUtils.putString("mEd_notifyUrl", mEd_notifyUrl.getText().toString().trim());
        mSpUtils.putString("mEd_subject", mEd_subject.getText().toString().trim());
        mSpUtils.putString("mEd_body", mEd_body.getText().toString().trim());
        mSpUtils.putString("mEd_amount", mEd_amount.getText().toString().trim());
        mSpUtils.putString("mEd_bankCardNo", mEd_bankCardNo.getText().toString().trim());
        mSpUtils.putString("mEd_cardId", mEd_cardId.getText().toString().trim());
        mSpUtils.putString("mEd_phoneNo", mEd_phoneNo.getText().toString().trim());
        mSpUtils.putString("mEd_remark", mEd_remark.getText().toString().trim());
        mSpUtils.putString("mEd_miyao", mEd_miyao.getText().toString().trim());

    }

    /**
     * onRestart()
     * 刷新订单号
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        mTime = TimeUtils.getTime();
        mEd_orderNo.setText(mTime);
        mBtt_tj.setClickable(true);
    }

    /**
     * initView
     * 初始化view
     */
    private void initView() {
        mEd_mid = (EditText) findViewById(R.id.ed_mid);
        mEd_mid.setText(mSpUtils.getString("mid"));
        mEd_notifyUrl = (EditText) findViewById(R.id.ed_notifyUrl);
        mEd_notifyUrl.setText(mSpUtils.getString("mEd_notifyUrl"));
        mEd_orderNo = (EditText) findViewById(R.id.ed_orderNo);
        mEd_orderNo.setText(mTime);
        mEd_amount = (EditText) findViewById(R.id.ed_amount);
        mEd_amount.setText(mSpUtils.getString("mEd_amount"));
        mEd_subject = (EditText) findViewById(R.id.ed_subject);
        mEd_subject.setText(mSpUtils.getString("mEd_subject"));
        mEd_body = (EditText) findViewById(R.id.ed_body);
        mEd_body.setText(mSpUtils.getString("mEd_body"));
        mEd_bankCardNo = (EditText) findViewById(R.id.ed_bankCardNo);
        mEd_bankCardNo.setText(mSpUtils.getString("mEd_bankCardNo"));
        mEd_cardId = (EditText) findViewById(R.id.ed_cardId);
        mEd_cardId.setText(mSpUtils.getString("mEd_cardId"));
        mEd_phoneNo = (EditText) findViewById(R.id.ed_phoneNo);
        mEd_phoneNo.setText(mSpUtils.getString("mEd_phoneNo"));
        mEd_bankCode = (TextView) findViewById(R.id.ed_bankCode);
        mEd_bankCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popCoding();
            }
        });
        mEd_remark = (EditText) findViewById(R.id.ed_remark);
        mEd_remark.setText(mSpUtils.getString("mEd_remark"));
        mEd_miyao = (EditText) findViewById(R.id.ed_miyao);
        mEd_miyao.setText(mSpUtils.getString("mEd_miyao"));
        mBtt_tj = (Button) findViewById(R.id.btt_tj);
        mBtt_tj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check(); //判断不能为空
                mBtt_tj.setClickable(false);
            }
        });
    }

    /**
     * gopayment
     * 判断code是否成功，成功进入Web页面进行加载html，未成功则提示用户错误信息。
     */
    private void gopayment() {
        saveData();//保存数据
        if (mShBean.getCode().equals("SUCCESS")) {
            saveData();//保存数据
            if (mFastPayment2ResultCodeBean.getResultCode().equals("SUCCESS")) {
                if (mShBean.getHtml() != null) {//成功则带值传入web页面
                    Intent intent = new Intent(FastPayment2MainActivity.this, WebViewActivity.class);
                    intent.putExtra("html", mShBean.getHtml());
                    startActivity(intent);
                } else {
                    ToastUtils.getToastUtils(mActivity, "html 字段有误请检查", 0);
                }
            } else {
                //失败提醒用户
                ToastUtils.getToastUtils(mActivity, mFastPayment2ResultCodeBean.getErrCodeDes(), 0);
                mBtt_tj.setClickable(true);
            }


        } else {
            //失败提醒用户
            ToastUtils.getToastUtils(mActivity, mShBean.getMsg(), 0);
            mBtt_tj.setClickable(true);
        }
    }

    /**
     * initListData
     * 添加银行和编码
     */
    private void initListData() {
        mListBeanList = new ArrayList<>();
        mListBeanList.add(new ListBean("昆仑银行", "617"));
        mListBeanList.add(new ListBean("浙商银行", "460"));
        mListBeanList.add(new ListBean("广州银行", "714"));
        mListBeanList.add(new ListBean("柳州银行", "643"));
        mListBeanList.add(new ListBean("汉口银行", "560"));
        mListBeanList.add(new ListBean("兴业银行", "309"));
        mListBeanList.add(new ListBean("中信银行", "106"));
        mListBeanList.add(new ListBean("东莞银行", "690"));
        mListBeanList.add(new ListBean("厦门银行", "605"));
        mListBeanList.add(new ListBean("龙江银行", "753"));
        mListBeanList.add(new ListBean("重庆银行", "652"));
        mListBeanList.add(new ListBean("徽商银行", "440"));
        mListBeanList.add(new ListBean("杭州银行", "735"));
        mListBeanList.add(new ListBean("民生银行", "360"));
        mListBeanList.add(new ListBean("交通银行", "350"));
        mListBeanList.add(new ListBean("工商银行", "102"));
        mListBeanList.add(new ListBean("大连银行", "611"));
        mListBeanList.add(new ListBean("恒丰银行", "628"));
        mListBeanList.add(new ListBean("北京银行", "370"));
        mListBeanList.add(new ListBean("广发银行", "320"));
        mListBeanList.add(new ListBean("上海银行", "420"));
        mListBeanList.add(new ListBean("农业银行", "103"));
        mListBeanList.add(new ListBean("南京银行", "390"));
        mListBeanList.add(new ListBean("平安银行", "340"));
        mListBeanList.add(new ListBean("华夏银行", "380"));
        mListBeanList.add(new ListBean("建设银行", "105"));
        mListBeanList.add(new ListBean("江苏银行", "624"));
        mListBeanList.add(new ListBean("包商银行", "550"));
        mListBeanList.add(new ListBean("招商银行", "310"));
        mListBeanList.add(new ListBean("中国银行", "104"));
        mListBeanList.add(new ListBean("天津银行", "565"));
        mListBeanList.add(new ListBean("吉林银行", "739"));
        mListBeanList.add(new ListBean("光大银行", "330"));
        mListBeanList.add(new ListBean("宁波银行", "512"));
        mListBeanList.add(new ListBean("哈尔滨银行", "567"));
        mListBeanList.add(new ListBean("上海农商银行", "795"));
        mListBeanList.add(new ListBean("邮政储蓄银行", "403"));
        mListBeanList.add(new ListBean("吉林农村信用社", "844"));
        mListBeanList.add(new ListBean("邯郸市商业银行", "551"));
        mListBeanList.add(new ListBean("东莞农村商业银行", "691"));
        mListBeanList.add(new ListBean("东莞农村商业银行", "691"));
        mListBeanList.add(new ListBean("云南省农村信用社", "831"));
        mListBeanList.add(new ListBean("福建省农村信用社", "700"));
        mListBeanList.add(new ListBean("重庆农村商业银行", "682"));
        mListBeanList.add(new ListBean("浙江省农村信用社", "841"));
        mListBeanList.add(new ListBean("海南省农村信用社", "726"));
        mListBeanList.add(new ListBean("广州农村商业银行", "641"));
        mListBeanList.add(new ListBean("北京农村商业银行", "511"));
        mListBeanList.add(new ListBean("乌海银行股份有限公司", "593"));
        mListBeanList.add(new ListBean("江苏省农村信用社联合社", "743"));
        mListBeanList.add(new ListBean("安徽省农村信用社联合社", "670"));
    }

    /**
     * popCoding
     * 选择银行附带id为银行编码
     */
    private void popCoding() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        final AlertDialog dialog = builder.create();
        View popcoding = View.inflate(mActivity, R.layout.listview_layout, null);
        dialog.setView(popcoding);
        dialog.setTitle("请您选择银行");
        ListView lv = (ListView) popcoding.findViewById(R.id.lv_xml);
        ListViewAdapter adapter = new ListViewAdapter(mActivity, mListBeanList);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mEd_bankCode.setText(mListBeanList.get(i).getName());
                mIntx = i;
                dialog.dismiss();
            }
        });
        dialog.show();

        WindowManager wm1 = this.getWindowManager();
        int height = wm1.getDefaultDisplay().getHeight() / 2;
        WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = ActionBar.LayoutParams.MATCH_PARENT;
        params.height = height;
        dialog.getWindow().setAttributes(params);
    }

    /**
     * check
     * 判断每个输入项不能为空
     */
    private void check() {
        if (TextUtils.isEmpty(mEd_mid.getText())) {
            ToastUtils.getToastUtils(mActivity, "商户名不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_notifyUrl.getText())) {
            ToastUtils.getToastUtils(mActivity, "通知URL不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_orderNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "订单号不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_subject.getText())) {
            ToastUtils.getToastUtils(mActivity, "商品名称不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_body.getText())) {
            ToastUtils.getToastUtils(mActivity, "商品描述不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_amount.getText())) {
            ToastUtils.getToastUtils(mActivity, "交易金额不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_bankCardNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "付款人银行卡不能为空", 0);
            return;
        }


        if (TextUtils.isEmpty(mEd_phoneNo.getText())) {
            ToastUtils.getToastUtils(mActivity, "付款人手机号不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_bankCode.getText())) {
            ToastUtils.getToastUtils(mActivity, "银行编码不能为空", 0);
            return;
        }
        if (TextUtils.isEmpty(mEd_cardId.getText())) {
            ToastUtils.getToastUtils(mActivity, "付款人身份证不能为空", 0);
            return;
        }

        if (TextUtils.isEmpty(mEd_miyao.getText())) {
            ToastUtils.getToastUtils(mActivity, "秘钥不能为空", 0);
            return;
        }
        //都不为空是封装数据
        initData();

    }

    /**
     * initData
     * 字段以数组的形式进行封装
     */
    private void initData() {

        if( !TextUtils.isEmpty(mEd_remark.getText())){
            mData = new String[]{"mid=" + mEd_mid.getText().toString().trim(),
                    "notifyUrl=" + mEd_notifyUrl.getText().toString().trim(),
                    "orderNo=" + mEd_orderNo.getText().toString().trim(),
                    "subject=" + mEd_subject.getText().toString().trim(),
                    "body=" + mEd_body.getText().toString().trim(),
                    "amount=" + mEd_amount.getText().toString().trim(),
                    "bankCardNo=" + mEd_bankCardNo.getText().toString().trim(),
                    "cardId=" + mEd_cardId.getText().toString().trim(),
                    "phoneNo=" + mEd_phoneNo.getText().toString().trim(),
                    "bankCode=" + mListBeanList.get(mIntx).getId(),
                    "remark=" + mEd_remark.getText().toString().trim(),
                    "noise=" + noise};
        }else{
            mData = new String[]{"mid=" + mEd_mid.getText().toString().trim(),
                    "notifyUrl=" + mEd_notifyUrl.getText().toString().trim(),
                    "orderNo=" + mEd_orderNo.getText().toString().trim(),
                    "subject=" + mEd_subject.getText().toString().trim(),
                    "body=" + mEd_body.getText().toString().trim(),
                    "amount=" + mEd_amount.getText().toString().trim(),
                    "bankCardNo=" + mEd_bankCardNo.getText().toString().trim(),
                    "cardId=" + mEd_cardId.getText().toString().trim(),
                    "phoneNo=" + mEd_phoneNo.getText().toString().trim(),
                    "bankCode=" + mListBeanList.get(mIntx).getId(),
                    "noise=" + noise};
        }
        String miyao = mEd_miyao.getText().toString().trim();
        //生成的签名
        String mEncode = SignatureUtils.initSort(mData, miyao);
        if (mEncode != null) {//签名不为空执行请求
            startThread(mEncode);
        }
    }


    /**
     * startThread
     * 开启子线程请求服务器
     */
    private void startThread(final String mEncode) {

        new Thread() {
            @Override
            public void run() {
                Map<String, Object> map = new HashMap<>();
                map.put("mid", mEd_mid.getText().toString().trim());                    //订单号
                map.put("notifyUrl", mEd_notifyUrl.getText().toString().trim());        //通知url
                map.put("orderNo", mEd_orderNo.getText().toString().trim());            //订单号已时间戳为准
                map.put("subject", mEd_subject.getText().toString().trim());            //商品名称
                map.put("body", mEd_body.getText().toString().trim());                  //商品描述
                map.put("amount", mEd_amount.getText().toString().trim());              //商品价格
                map.put("bankCardNo", mEd_bankCardNo.getText().toString().trim());      //付款方银行卡号
                map.put("cardId", mEd_cardId.getText().toString().trim());              //付款方省份号
                map.put("phoneNo", mEd_phoneNo.getText().toString().trim());            //付款方手机号
                map.put("bankCode", mListBeanList.get(mIntx).getId());                  //银行编码

                if (!TextUtils.isEmpty(mEd_remark.getText())) {
                    map.put("remark", mEd_remark.getText().toString().trim());
                }
                map.put("remark", mEd_remark.getText().toString().trim());              //备注
                map.put("noise", noise);                                                //随机字符串要求不超过32位，本dome以16位为基础
                map.put("sign", mEncode);                                               //签名，以最新聚融通在线文档签名为准
                Log.i("mEncode", mEncode + "----");
                //发送请求
                String result = UtilsPost.postUrlConnect(url, map);
                if (result != null) {
                    Log.i("result", result + "---成功");
                    mShBean = GsonUtils.toGlass(result, FastPayment2Bean.class);
                    mFastPayment2ResultCodeBean = GsonUtils.toGlass(result, FastPayment2ResultCodeBean.class);
                    Message message = new Message();
                    message.what = 1;
                    mHandler.sendMessage(message);
                } else {
                    Log.i("result", "失败");
                    Message message = new Message();
                    message.what = 3;
                    mHandler.sendMessage(message);
                }

            }
        }.start();
    }


}
