package tfcpay.demo.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by a on 2017/9/26.
 */

public class TimeUtils {
    /**
     * getTime
     * 生成时间戳
     */
    public static String getTime() {
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
        return   df.format(new Date());
    }
}
