package tfcpay.demo;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import tfcpay.demo.FastPayment2Activity.FastPayment2MainActivity;
import tfcpay.demo.FastPaymentActivity.FastPaymentMainActivity;


/**
 * MainActivity
 * 首页区分快捷类型
 */
public class MainActivity extends AppCompatActivity {

    @BindView(R.id.id_fastpayment)
    Button mIdFastpayment;
    @BindView(R.id.id_fastpayment2)
    Button mIdFastpayment2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
    }

    /**
     * 点击事件
     * @param view  进入选择的渠道
     */
    @OnClick({R.id.id_fastpayment, R.id.id_fastpayment2})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.id_fastpayment://快捷支付(同名进出)
                Intent FastPayment=new Intent(MainActivity.this, FastPaymentMainActivity.class);
                startActivity(FastPayment);
                break;
            case R.id.id_fastpayment2://快捷支付(同名进出)2
                Intent FastPayment2=new Intent(MainActivity.this, FastPayment2MainActivity.class);
                startActivity(FastPayment2);
                break;
        }
    }
}
