# TFCPAY Android Demo
#### 简介
1. 以最新[聚融通在线文档](https://open.tfcpay.com/#/open_api/)为准。

2.使用过程遇到问题，则参考对应的demo
### 版本要求
Android Studio最低版本2.0,SDK最低要求5.0
### 使用实例
1.使用Android Studio打开demo工程

2.快捷支付(同名进出)签名获取,以最新聚融通在线文档[数字签名](https://open.tfcpay.com/#/open_api/qianming)为准

3.具体详情参考本demo
### 示例说明
目前提供demo示例为：

1.快捷支付（同名进出)

2.快捷支付（同名进出）2

