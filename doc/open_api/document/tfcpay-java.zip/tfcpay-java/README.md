TFCPAY Java Demo
============

### 简介
1. 以最新[聚融通在线文档](https://open.tfcpay.com/#/open_api/)为准。
2. 说明见index.jsp 。
3. 使用前需把Constants.java中的mid和key换成测试的账号


### 版本要求

Java SDK 要求 JDK 版本 1.8 及以上

### 本Demo依赖jar包如下

``` 
<httpClient.version>4.3.6</httpClient.version>
<lang3.version>3.4</lang3.version>
<slf4j.version>1.7.19</slf4j.version>
<fastjson.version>1.2.12</fastjson.version>
<servlet.api>3.1.0</servlet.api>
```


### 使用示例
```
参考 java/com/tfcpay/demo
网银参考 webapp/netpay.jsp
快捷支付2参考  com/tfcpay/demo/QuickPay2Test.java
商户进件参考    com/tfcpay/demo/RegisterTest.java
商户进件[新]参考  com/tfcpay/demo/RegisterNewTest.java
单笔订单查询参考   com/tfcpay/demo/QuerysingleTest.java
多笔订单查询参考   com/tfcpay/demo/QueryMultiTest.java
扫码支付参考          com/tfcpay/demo/PayCodeTest.java
代付申请参考          com/tfcpay/demo/DefrayTest.java
代付结果查询参考   com/tfcpay/demo/DefrayQueryTest.java
```

### 示例说明
```
目前提供demo示例为:
1、异步通知接口
2、扫码支付
3、刷卡支付
4、快捷支付2
5、商户进件
6、商户进件[新]
7、单笔订单查询
8、多笔订单查询
9、代付申请
10、代付结果查询
```
