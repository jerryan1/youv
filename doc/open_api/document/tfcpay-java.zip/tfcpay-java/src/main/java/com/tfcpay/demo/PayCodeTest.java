package com.tfcpay.demo;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.exception.TfcpayBussinessException;
import com.tfcpay.exception.TfcpaySignException;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;

/**
 * 扫码支付 相关示例
 *
 * 该实例程序演示了扫码支付接口的调用，验签和业务返回基本处理。
 *
 * 开发者需要在config/Constants 配置 MID 和 KEY，
 * 
 * 会产生真正的交易，测试过程中需谨慎输入金额
 * 
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 *
 */
public class PayCodeTest {
	
	//测试商户号
	static String mid="812017050323777";
	//测试密钥
	static String singKey = "ddbax6n4cg8qj958ytt6";
	
	
	public static void main(String[] args) {

		// 扫码支付
		paycode();
	}

	/***
	 * QQ钱包/微信/支付宝 扫码支付demo
	 */
	public static void paycode() {

		// 支付类型 wechat:微信 alipay:支付宝 QQwallet:QQ钱包
		String type = "wechat";
	
		// 订单号
		String orderNo = TfcpayUtil.nextUUID();
		// 随机数
		String noise = TfcpayUtil.nextUUID();

		Map<String, Object> pay = new HashMap<>();
		// 商户号，通过配置获取，只做参考
		pay.put("mid", mid);
		// 订单号随机一下，防止订单重复
		pay.put("orderNo", orderNo);
		pay.put("subject", "订单标题");
		pay.put("body", "订单描述");
		// 金额位元,如需转换参考BigDecimalUtil工具类
		pay.put("amount", new BigDecimal("0.02"));
		pay.put("type", type);
		// 通知地址
		pay.put("notifyUrl", Constants.NOTIFYURL);
		// 随机字符串,
		pay.put("noise", noise);

		Map<String, String> data = null;
		try {
			// 生成sign, 并转Map<String,Object> 为Map<String,String>
			data = TfcpayUtil.flattenParamsAndSign(pay, singKey);
			String result = HttpUtil.post(Constants.PAYCODE_URL, data);
			System.out.println("请求返回内容\n" + result);
			Map<String, String> resultMap = TfcpayUtil.parseResult(result);

			// 输入结果
			ResultMain(resultMap);

		} catch (IOException e) {
			System.out.println("请求异常");
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/***
	 * 结果打印
	 * 
	 * @param resultMap
	 */
	public static void ResultMain(Map<String, String> resultMap) {
		try {
			//对返回结果进行验签
			if (TfcpayUtil.VerifySign(resultMap, singKey)) {
				// 验签成功
				String code = resultMap.get("code");
				String resultCode = resultMap.get("resultCode");
				if ("SUCCESS".equals(code) && "SUCCESS".equals(resultCode)) {
					// 业务正常，巴拉巴拉获取想要的内容
					// 二维码
					String qrCode = resultMap.get("qrCode");
					// 交易金额:注意,交易金额为元.角分格式，转换需注意,可参考转换工具类BigDecimalUtil
					BigDecimal amount = new BigDecimal(String.valueOf(resultMap.get("amount")));
					System.out.println("----------------正常业务输出-------------");
					System.out.println("内容\n" + JSONObject.toJSONString(resultMap));
					System.out.println("-----------------------------");

				} else {
					String errCode = resultMap.get("errCode");
					String errCodeDes = resultMap.get("errCodeDes");
					System.out.println("----------------异常业务输出-------------");
					System.out.println("--errCode:" + errCode);
					System.out.println("--errCodeDes:" + errCodeDes);
					System.out.println("内容\n" + JSONObject.toJSONString(resultMap));
					System.out.println("-----------------------------");
				}
			} else {
				System.out.println("验签失败-------------");
			}
		} catch (TfcpaySignException e) {

			System.out.println(e.getMessage());
			System.out.println(e.getParam());
			e.printStackTrace();
		}catch (TfcpayBussinessException e) {
			System.out.println("业务异常-------------"+e.getMessage());
			e.printStackTrace();
		}
	}

}
