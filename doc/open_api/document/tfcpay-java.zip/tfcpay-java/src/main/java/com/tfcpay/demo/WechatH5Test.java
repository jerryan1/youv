package com.tfcpay.demo;

import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.RandomStringUtils;

import com.tfcpay.config.Constants;
import com.tfcpay.util.TfcpayUtil;

/**
 * 微信H5 相关示例
 *
 * 该实例程序演示了微信H5支付， 验签和业务返回基本处理。
 * 
 * 开发者需要自己配置 MID 和 KEY和其它相关参数
 * 
 * 会产生真正的交易，测试过程中需谨慎输入金额
 * 
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 *
 * 注意事项:
 * 
 * H5支付是指商户在微信客户端外的移动端网页展示商品或服务，用户在前述页面确认使用微信支付时，商户发起本服务呼起微信客户端进行支付。
 * 主要用于触屏版的手机浏览器请求微信支付的场景。可以方便的从外部浏览器唤起微信支付。 
 */

 /** 
 * @ClassName:  WechatH5Test
 * @Description:
 * @author liuxin
 * @date 2017年9月18日 上午9:52:21
 */
public class WechatH5Test {
	private static final String MID="812017090124354";
	private static final String KEY="wh8uco2pv5pkda741gv3";
	public static void main(String[] args) {
		wechatH5();
	}

	private static void wechatH5() {
		Map<String, Object> params = new TreeMap<>();
		params.put("mid", MID);
		params.put("orderNo", System.currentTimeMillis());
		params.put("subject", "可乐");
		params.put("body", "大桶可口可乐");
		params.put("amount", "0.2");
		params.put("notifyUrl", "www.baidu.com");
		params.put("ip", "127.0.0.1");
		params.put("deviceInfo", "AND_WAP");
		params.put("callbackUrl", "www.baidu.com");
		params.put("mchAppId", "https://m.jd.com");
		params.put("mchAppName", "https://m.jd.com");
		params.put("noise", RandomStringUtils.randomAlphanumeric(32));//noise
		TfcpayUtil.sendTo(params, Constants.WECHAT_H5_URL, KEY); // 发送HTTP请求
	}
}
