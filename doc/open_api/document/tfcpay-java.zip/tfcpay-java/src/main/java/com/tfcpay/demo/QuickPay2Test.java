package com.tfcpay.demo;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;

/**
 * @date 2017年9月25日  上午9:20
 * @author LuCunxin
 * 快捷支付2 <br>
 * 使用说明: <br>
 * 1:调用报备接口{@link com.tfcpay.demo.RegisterTest} <br>
 * 2:使用报备接口返回的商户号与商户密钥进行下单 <br>
 * 3:将返回的JSON中的html字段用浏览器加载后在跳转的银联页面完成支付 <br>
 * 4:我方平台异步通知您在下单申请时上送的notifyUrl中的通知地址{@link com.tfcpay.controller.Notify}
 */
public class QuickPay2Test {
	
	static final String MID = "822017092624485";			//商户号
	static final String KEY = "1ocpd73opwgn3a740uhb";		//密钥

	public static void main(String[] args) {
		directPay();
	}
	
	/** API下单申请 */
	public static void directPay() {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("mid", MID);                                                  //商户号
		param.put("notifyUrl", Constants.NOTIFYURL);                            //异步通知地址
		param.put("orderNo", System.currentTimeMillis() + "");                  //商户订单号
		param.put("subject", "可乐");                                            //商品的标题
		param.put("body", "大桶可口可乐");                                          //商品的具体描述
		param.put("amount", "100");                                             //交易的总金额，单位为元
		param.put("bankCardNo", "622**********071");                            //付款方银行卡号
		param.put("cardId", "230306********4510");                              //卡在银行预留身份证号码
		param.put("phoneNo", "188****7354");                                    //卡在银行预留的手机号码
		param.put("bankCode", "310");                                           //银行卡编号
		param.put("remark", "备注");                                             //备注
		param.put("noise", TfcpayUtil.nextUUID());                              //随机字符串
		Map<String, String> data = TfcpayUtil.flattenParamsAndSign(param, KEY); //生成签名
		System.out.println(JSON.toJSONString(data));
		String resultStr = HttpUtil.tryPost(Constants.QUICKPAY_B2C_URL, data, "utf-8");     //发送HTTP请求
		JSONObject resultJson = JSON.parseObject(resultStr);
		System.out.println("返回码: "+resultJson.getString("code"));
		System.out.println("返回消息: "+resultJson.getString("msg"));
		if(!"SUCCESS".equals(resultJson.getString("code"))){
			System.out.println("通道订单处理失败");
			return;
		}else {
			System.out.println("返回状态码: "+resultJson.getString("resultCode"));
			System.out.println("错误代码: "+resultJson.getString("errCode"));
			System.out.println("错误代码描述: "+resultJson.getString("errCodeDes"));
			System.out.println("随机字符串: "+resultJson.getString("noise"));
			System.out.println("商户号: "+resultJson.getString("mid"));
			System.out.println("商户订单号: "+resultJson.getString("orderNo"));
			System.out.println("签名: "+resultJson.getString("sign"));
			if("SUCCESS".equals(resultJson.getString("resultCode"))){
				//返回HTML页面后需要将返回的字符取出用浏览器访问后完成支付
				System.out.println("聚融通平台账单号: "+resultJson.getString("flowNo"));
				System.out.println("银联返回页面: "+resultJson.getString("html"));
			}
		}
		
	}

}
