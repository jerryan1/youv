package com.tfcpay.demo;

import java.util.HashMap;
import java.util.Map;

import com.tfcpay.config.Constants;
import com.tfcpay.util.TfcpayUtil;

/**
 * 快捷支付 相关示例
 *
 * 该实例程序演示了快捷支付接口的调用，验签和业务返回基本处理。
 *
 * 开发者需要填写 mid 和 key，
 * 
 * 会产生真正的交易，测试过程中需谨慎输入金额
 * 
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 *
 * 注意事项: 
 * 
 */
/**
 * 1、新增了 开通快捷支付接口，持卡人第一次消费前，需要先调用这个接口开通支付功能；只需要开通一次，无需重复开通
   2、付款卡仅支持贷记卡，收款卡只支持借记卡；只允许同名进出
   3、先测试，然后再上生产；所以测试期间，不要发太多交易；测试环境是真实扣款和真实代付，但是手续费不返还
   4、测试和生产环境，单笔都是最低800元，最高2万
   5、交易时间，00:20-22:00
  具体支持的银行卡列表,请询问运营人员
 * @ClassName:  QuickPayTest
 * @Description:
 * @author liuxin
 * @date 2017年9月14日 下午3:28:18
 */
public class QuickPayTest {

	static final String MID = "822017101127057";			//商户号
	static final String KEY = "l7fm3j190c2jzyjqlmng";		//密钥

	public static void main(String[] args) {
	
		openDirect();
		
	//	directPay();
		
	//	payment();
	
	//	mobilepay();
	}

	
	/***
	 * 开通快捷支付功能
	 * @Description: 
	 * @author liuxin 
	 * @date 2017年10月31日 上午11:09:06       
	 * @throws
	 */
	public static void openDirect() {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("mid", MID);									//商户号
		param.put("realName", "meteor");						//付款方持卡人姓名
		param.put("cardId", "1234");							//卡在银行预留身份证号码
		param.put("phoneNo", "15311372348");					//卡在银行预留的手机号码
		param.put("bankCode", "105");							//银行卡编号
		param.put("bankCardNo", "62531642312718912");			//付款方银行卡号
		param.put("flowNo", System.currentTimeMillis() + "");	//请求流水号
		param.put("returnUrl", Constants.NOTIFYURL);			//开通成功商户回调地址
		param.put("noise", TfcpayUtil.nextUUID());				//随机字符串
		TfcpayUtil.sendTo(param,Constants.QUICKPAY_OPENDIRECT_URL,KEY);	//发送HTTP请求

	}

	
	
	/** API快捷预下单 */
	public static void directPay() {
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("mid", MID);									//商户号
		param.put("notifyUrl", Constants.NOTIFYURL);			//异步通知地址
		param.put("orderNo", System.currentTimeMillis() + "");	//商户订单号
		param.put("subject", "可乐");							//商品的标题
		param.put("body", "大桶可口可乐");						//商品的具体描述
		param.put("amount", "100");								//交易的总金额，单位为元
		param.put("cardType", "02");							//付款方卡类标识
		param.put("bankCardNo", "62531642312718912");			//付款方银行卡号
		param.put("realName", "meteor");						//付款方持卡人姓名
		param.put("cardId", "1234");							//卡在银行预留身份证号码
		param.put("phoneNo", "15311372348");					//卡在银行预留的手机号码
		param.put("expireMonth", "06");							//信用卡有效期月份
		param.put("expireYear", "20");							//信用卡有效期年份
		param.put("cvv", "837");								//信用卡CVV码
		param.put("bankCode", "105");							//银行卡编号
		param.put("feeRate", "0.30");							//费率，不带百分号如果费率为0.4% 则传0.4
		param.put("mustAmt", "3");								//固定金额，默认为0
		param.put("isPrivate", "02");							//01对公 02对私
		param.put("receivedCardNo", "6214823434526878");		//收款方银行卡号
		param.put("receivedPhoneNo", "1534312038");				//收款方手机号码
		param.put("receivedBankCode", "310");					//收款方银行编码
		param.put("noise", TfcpayUtil.nextUUID());				//随机字符串
		TfcpayUtil.sendTo(param,Constants.QUICKPAY_DIRECTPAY_URL,KEY);			//发送HTTP请求
	}

	
	
	/** API确认支付 */
	public static void payment() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("mid", MID);								//商户号
		data.put("orderNo", "15051081345500");				//商户订单号
		data.put("verifyCode", "384890");					//短信验证码
		TfcpayUtil.sendTo(data,Constants.QUICKPAY_PAYMENR_URL,KEY);
	}

	
	/** 手机控件支付（订单获取） */
	public static void mobilepay() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("mid", MID);
		data.put("notifyUrl", Constants.NOTIFYURL);
		data.put("orderNo", System.currentTimeMillis() + "");
		data.put("subject", "可乐");
		data.put("body", "大桶可口可乐");
		data.put("amount", "15356.25");
		data.put("bankCardNo", "6253621202438912");
		data.put("feeRate", "0.50");
		data.put("mustAmt", "30");
		data.put("receivedCardNo", "621483011224878");
		data.put("receivedCardId", "41152819123083499");
		data.put("receivedPhoneNo", "15314230238");
		data.put("receivedBankCode", "105");
		data.put("receivedRealName", "刘新");
		TfcpayUtil.sendTo(data,Constants.QUICKPAY_MOBILEPAY_URL,KEY);
	}
}
