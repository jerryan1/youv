package com.tfcpay.demo;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import com.alibaba.fastjson.JSON;
import com.tfcpay.config.Constants;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;

/**
 * 对账文件下载演示示例  此示例仅供参考 (beta)
 * 该实例程序演示了对账文件下载接口的调用，签名和业务返回基本处理。
 * 开发者需要填写 mid 和 key，
 */
public class BillDownloadTest {

	static final String MID = "812017091324422";			//商户号
	static final String KEY = "9z5u49jt90rb4yb0lxc9";		//密钥

	
	public static void main(String[] args) {
		billDownload();
	}

	
	public static void billDownload(){
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("mid", MID);						//商户号
		data.put("billType", "DF");					//账单类型   DZ:支付流水对账单 DF:代付流水对账单
		data.put("billDate", "20170913");	    	//账单日期   格式:yyyyMMdd 三个月之内的账单
		data.put("noise", TfcpayUtil.nextUUID());   //随机数 用于混淆加密
		sendTo(data,Constants.BILLDOWNLOAD_URL);
	}
	

	
	/**
	 * 发送请求并对返回结果进行处理 如果是文件流则写入到本地 如果是错误信息 则输出
	 * @param param
	 * @param url
	 */
	private static void sendTo(Map<String, Object> param,String url){
		Map<String, String> data = null;
		try {
			data = TfcpayUtil.flattenParamsAndSign(param, KEY);
			String result = HttpUtil.post(url,data);
			//首先判断返回的内容是文件流 还是json
			if(judgeStatus(result)){
				//文件位置
				String fileName = "E:\\result.csv";
				System.out.println("成功获取文件 写入文件到:" + fileName);
				//写文件到该目录下
				writeStrToFile(fileName, result);
				//好了快去看看文件有了没
			}else{
				System.out.println("对账文件下载业务不成功:返回内容\n" + result);
			}
		}catch (IOException e) {
			System.out.println("请求异常");
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	
	
	/**
	 * 通过对返回内容转json出现异常则表明返回的是文件流 供参考
	 * @param text
	 * @return
	 */
	public static boolean judgeStatus(String text) {
		try {
			JSON.parseObject(text);
		} catch (Exception e) {
			return true;
		}
		return false;
	}

	
	/**
	 * 传入文件名以及字符串, 将字符串信息保存到文件中
	 * @param fileName
	 * @param strBuffer
	 */
	public static void writeStrToFile(String fileName, final String strBuffer) {
		try {
			// 创建文件对象
			File fileText = new File(fileName);
			// 向文件写入对象写入信息
			FileWriter fileWriter = new FileWriter(fileText);
			// 写文件
			fileWriter.write(strBuffer);
			// 关闭
			fileWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	  
	
}
