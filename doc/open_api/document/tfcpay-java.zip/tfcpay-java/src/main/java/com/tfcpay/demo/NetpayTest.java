package com.tfcpay.demo;

import java.util.HashMap;
import java.util.Map;

import com.tfcpay.config.Constants;
import com.tfcpay.util.TfcpayUtil;

/**
 * 网银支付 相关示例
 *
 * 该实例程序演示了网银支付数据的提交,网银支付以form表单方式提交数据,没有同步返回数据
 * 
 * 支付成功后会有异步通知
 *
 * 开发者需要填写mid和key及其它业务参数
 * 
 * 会产生真正的交易，测试过程中需谨慎输入金额
 * 
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 * 
 * 注意事项:
 * 1.如果请求的业务类型为收银台模式,请勿传入bankCode
 * 2.如果请求的业务类型为API模式,请传入bankCode,具体支持的银行以商务实际签约为准
 */
/***
 * 
 * @ClassName:  NetpayTest
 * @Description:
 * @author liuxin
 * @date 2017年9月14日 下午4:27:47
 */
public class NetpayTest {

	static final String MID = "812017050323777"; // 商户号
	static final String KEY = "ddbax6n4cg8qj958ytt6"; // 密钥

	public static void main(String[] args) {
		netpay();
	}

	private static void netpay() {
		String mid = MID; // 商户号
		String orderNo = System.currentTimeMillis() + ""; // 合作伙伴系统中的订单号
		String amount = "1.21"; 						  // 订单金额
		String bankCode = "102"; 						  // 业务类型为收银台,为空。其他必填
		String notifyUrl = "www.baidu.com"; 			  // 针对该交易的交易状态同步通知接收URL
		String returnUrl = "www.baidu.com"; 			  // 用于支付完成后跳转到商户网站指定的地址
		String currencyType = "CNY"; 					  // 货币类型
		String subject = "subject"; 					  // 商品名称
		String body = "body"; 							  // 商品的具体描述
		String cardType = "01"; 						  // 卡类型
		String channel = "01"; 							  // 来源类型
		String businessType = "01"; 					  // 业务类型
		String remark = "test"; 						  // 备注
		String noise = TfcpayUtil.nextUUID(); 			  // 随机字符串
		String gatewayUrl = Constants.NETPAY_URL;

		Map<String, String> data = new HashMap<String, String>();
		data.put("mid", mid);
		data.put("orderNo", orderNo);
		data.put("amount", amount);
		data.put("bankCode", bankCode);
		data.put("notifyUrl", notifyUrl);
		data.put("returnUrl", returnUrl);
		data.put("currencyType", currencyType);
		data.put("subject", subject);
		data.put("body", body);
		data.put("cardType", cardType);
		data.put("channel", channel);
		data.put("businessType", businessType);
		data.put("remark", remark);
		data.put("noise", noise);
		String sign = TfcpayUtil.generateMD5(data, KEY);
		data.put("sign", sign);

		StringBuffer buffer = new StringBuffer();
		buffer.append("<form action='").append(gatewayUrl).append("' id='form' method='post' target='_blank'>\n");
		buffer.append("<input name='mid' value='").append(mid).append("' type='hidden'>\n");
		buffer.append("<input name='orderNo' value='").append(orderNo).append("' type='hidden'>\n");
		buffer.append("<input name='amount' value='").append(amount).append("' type='hidden'>\n");
		buffer.append("<input name='bankCode' value='").append(bankCode).append("' type='hidden'>\n");
		buffer.append("<input name='notifyUrl' value='").append(notifyUrl).append("' type='hidden'>\n");
		buffer.append("<input name='returnUrl' value='").append(returnUrl).append("' type='hidden'>\n");
		buffer.append("<input name='currencyType' value='").append(currencyType).append("' type='hidden' >\n");
		buffer.append("<input name='subject' value='").append(subject).append("' type='hidden' >\n");
		buffer.append("<input name='body' value='").append(body).append("' type='hidden' >\n");
		buffer.append("<input name='cardType' value='").append(cardType).append("' type='hidden'>\n");
		buffer.append("<input name='channel' value='").append(channel).append("' type='hidden'>\n");
		buffer.append("<input name='businessType' value='").append(businessType).append("' type='hidden'>\n");
		buffer.append("<input name='remark' value='").append(remark).append("' type='hidden'>\n");
		buffer.append("<input name='noise' value='").append(noise).append("' type='hidden'>\n");
		buffer.append("<input name='sign' value='").append(sign).append("' type='hidden'>\n");
		buffer.append("</form>\n");
		buffer.append("<script>document.getElementById(\"form\").submit()");
		buffer.append("</script>");
		/**
		 * 输出表单数据,将以下内容复制到新建的html文本中,刷新网页即可看到效果
		 */
		System.out.println(buffer.toString());
		/**
		 * 或者假设你有HttpServletResponse,这样就可以输出了
		 * response.setContentType("text/html;charset=utf-8");
		 * response.setCharacterEncoding("utf-8"); 
		 * PrintWriter out =response.getWriter(); 
		 * out.println(buffer.toString());
		 */
	}
}
