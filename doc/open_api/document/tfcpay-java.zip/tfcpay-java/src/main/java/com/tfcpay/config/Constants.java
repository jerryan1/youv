package com.tfcpay.config;

/***
 * 公用配置参数，只做参考使用
 * @author lihejia
 *
 */
public class Constants {
	
	
	/**商户号**/
	public static String MID="812017090824399";
	
	/**商户号密钥:**/
	public static String KEY="amlzh0yqgouyavnhfrob";
	
	
	/** 机构商户号 **/
	public static String AGENT_MID = "812017081524279";

	/** 机构商户号密钥**/
	public static String AGENT_KEY = "q485ghzz6nmr5duhctal";
	
	
	/***
	 * 通知地址,运行本项目起来以后会有一个接受通知的测试，请修改为外网可访问地址
	 */
	public static String NOTIFYURL="http://192.168.1.154:8080/tfcpay-java/notify";
	
	/***测试地址*/
	public static String DEV_DOMAIN="https://devapi.tfcpay.com/v2";
	
	/**扫码支付地址**/
	public static String PAYCODE_URL=DEV_DOMAIN+"/pay/paycode";
	
	/**刷卡支付地址**/
	public static String BRUSHCARD_URL=DEV_DOMAIN+"/pay/brushcard";
	
	/**刷卡支付撤销地址**/
	public static String BRUSHCARD_REVOKE_URL=DEV_DOMAIN+"/pay/brushcard/revoke";
	
	/**刷卡支付查询地址**/
	public static String BRUSHCARD_QUERY_URL=DEV_DOMAIN+"/query/brushcard";
	
	/**快捷支付API预下单**/
	public static String QUICKPAY_DIRECTPAY_URL=DEV_DOMAIN+"/quickPay/directPay";
	
	/**快捷支付 开通快捷支付*/
	public static String QUICKPAY_OPENDIRECT_URL=DEV_DOMAIN+"/quickPay/directPay";
	
	/**API预下单确认支付**/
	public static String QUICKPAY_PAYMENR_URL=DEV_DOMAIN+"/quickPay/payment";
	
	/**快捷支付手机控件SDK预下单**/
	public static String QUICKPAY_MOBILEPAY_URL=DEV_DOMAIN+"/quickPay/mobilePay";
	
	/**快捷支付(B2C)收银台**/
	public static String QUICKPAY_B2C_URL=DEV_DOMAIN+"/quickPay/quickPayB2c";
	
	/**网银支付请求地址*/
	public static String NETPAY_URL=DEV_DOMAIN+"/netpay";

	/**商户注册请求地址*/
	public static String MERCHANT_REGISTER_URL=DEV_DOMAIN+"/merchant/register";

	/**微信H5支付请求地址*/
	public static String WECHAT_H5_URL=DEV_DOMAIN+"/pay/wap/wechat";

	/** 商户报备 */
	public static final String MERCHANT_REGISTER_NEW_URL = DEV_DOMAIN + "/merchant/create";
	
	/**订单单笔查询**/
	public static final String QUERY_SINGLE_URL = DEV_DOMAIN + "/query/single";
	
	/**订单批量查询**/
	public static final String QUERY_MULTI_URL = DEV_DOMAIN + "/query/multi";
	
	/**代付下单**/
	public static final String DEFRAY_URL = DEV_DOMAIN + "/defray";
	
	/**代付查询**/
	public static final String DEFRAY_QUERY_URL = DEV_DOMAIN + "/defray/query";
	
	/**查询w**/
	public static final String QUERY_BANKS_URL = DEV_DOMAIN + "/query/banks";
	
	/**对账文件下载 **/
	public static final String BILLDOWNLOAD_URL = DEV_DOMAIN + "/merchant/billdownload";

	
}

