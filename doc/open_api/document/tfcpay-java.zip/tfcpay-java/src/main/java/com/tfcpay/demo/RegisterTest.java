package com.tfcpay.demo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.exception.TfcpayBussinessException;
import com.tfcpay.exception.TfcpaySignException;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;
/**
 * 商户报备 相关示例
 * 该实例程序演示了商户报备接口的调用,用于完成机构商户下二级商户的注册
 * 开发者需要填写 mid 和 key 及其它参数信息
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 * 
 * 注意事项: 
 * 1.mid请使用机构商户号
 * 2.参数extendParams是标准的JSONObject字符串,其中value值为JSONArray
 * 3.该Demo仅供参考
 * 4.该接口示例与 {@link}RegisterNewTest 属于同一用途 只不过此接口是老版本 如无特殊说明建议使用新接口
 */
/**
 * 
 * @ClassName:  RegisterTest
 * @Description:
 * @author liuxin
 * @date 2017年9月15日 上午9:46:22
 */
public class RegisterTest {
	

	public static void main(String[] args) {
		register();
	}
	

	private static void register() {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("mid", Constants.AGENT_MID);							//商户号
		data.put("merchantName", "demo:register添加");				    //商户名称
		data.put("merchantAlias", "demo:register添加");				    //商户简称
		data.put("weChatCategory", "9");								//微信经营类目
		data.put("alipayCategory", "2016062900190213"); 				//支付宝经营类目
		data.put("idCard", "41152564545665465555");						//身份证号码
		data.put("realName", "东皇太一");									//真实姓名
		data.put("phoneNumber", "15655646565");							//手机号码
		data.put("bankCard", "621489265689856");						//借记卡号
		data.put("bankLinked", "104171306669");							//借记卡联行号
		data.put("creditBankCard", "656461263532152");					//信用卡号	
		data.put("creditBankLinked", "104171306669");					//信用卡联行号
		data.put("cardAccountType", "01");								//卡帐户类型
		data.put("noise", TfcpayUtil.nextUUID());						//随机字符串
		data.put("extendParams",										//拓展字段,用于存放支付授权代付授权信息
				"{\"03\":[{\"01\":\"11.11\"}],\"04\":[{\"01\":\"12.12\"}],\"00\":[{\"D0\":\"0.13\"},{\"T1\":\"0.14\"},{\"M0\":\"3\"},{\"M1\":\"4\"}]}");
		
		Map<String, String> registerMap = null;
		try {
			//生成sign, 并转Map<String,Object> 为Map<String,String>
			registerMap = TfcpayUtil.flattenParamsAndSign(data, Constants.AGENT_KEY);
			//发送HTTP请求
			String result = HttpUtil.post(Constants.MERCHANT_REGISTER_URL, registerMap);
			System.out.println("商户进件返回内容如下:\n" + result);
			//将返回结果的JSON字符串转为Map方便取数据
			Map<String, String> resultMap = TfcpayUtil.parseResult(result);
			//根据返回的内容进行业务处理
			bussinessHandle(resultMap);
		} catch (IOException e) {
			System.out.println("请求异常");
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	
	/**
	 * 业务处理
	 * @param resultMap
	 */
	public static void bussinessHandle(Map<String, String> resultMap) {
		try {
			//对返回结果进行验签  验签失败会丢出异常
			TfcpayUtil.VerifySign(resultMap, Constants.AGENT_KEY);
			//如果代码执行到这里说明验签成功
			String code = resultMap.get("code");
			String resultCode = resultMap.get("resultCode");
			if ("SUCCESS".equals(code) && "SUCCESS".equals(resultCode)) {
				// 业务正常，巴拉巴拉获取想要的内容
				System.out.println("----------------正常业务输出-------------");
				System.out.println("内容\n" + JSONObject.toJSONString(resultMap));
				System.out.println("-----------------------------");
				//内容已经有了 要做什么请发挥你的想象力
				System.out.println("进件返回的mid:"+resultMap.get("merchantId") + " 密钥:"+resultMap.get("encryptKey"));
			}
		} catch (TfcpaySignException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getParam());
			e.printStackTrace();
		}catch (TfcpayBussinessException e) {
			System.out.println("业务异常-------------"+e.getMessage());
			e.printStackTrace();
		}
	}
	
	
}
