package com.tfcpay.demo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.exception.TfcpayBussinessException;
import com.tfcpay.exception.TfcpaySignException;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;

/**
 * 代付下单相关示例
 * 该实例程序演示了代付接口的调用，验签和业务返回基本处理。
 * 开发者需要在config/Constants 配置 MID 和 KEY，
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 *
 */
public class DefrayTest {
	
	/** 商户号 **/
	private static final String MID = "812017050323777";
	/** 商户密钥 **/
	private static final String KEY = "ddbax6n4cg8qj958ytt6";
	

	public static void main(String[] args) {
		//代付
		defray();
	}


	public static void defray() {
		Map<String, Object> pay = new HashMap<>();
		pay.put("mid", MID); 										//商户号，通过配置获取，只做参考
		pay.put("orderNo", TfcpayUtil.nextUUID()); 					//商户订单号(订单号必须保证唯一性) 这里用随机数随机生成一个
		pay.put("amount", "10.00");					            	//订单金额  代付金额 单位为元  格式为0.00   生产环境有代付最小金额限制 详情咨询运营
		pay.put("receiveName", "张三");								//收款人姓名
		pay.put("openProvince", "广西");								//开户省
		pay.put("openCity", "北海市");								//开户市
		pay.put("bankCode", "105");									//收款银行编码  见 银行简码
		pay.put("bankBranchName", "中国工商银行北海分行云南路支行");   		//支行名称
		pay.put("cardNo", "8011101509400060000");					//卡号
		pay.put("type", "02");										//01 普通 02 额度
		pay.put("noise", TfcpayUtil.nextUUID());					//随机字符串,不长于32位
		//pay.put("extendParams", "");								//扩展字段 一般情况下此字段不需要传
		pay.put("cardAccountType", "01");							//01 个人 02 企业   01即为对私 02即为对公
		pay.put("bankLinked", "102623053001");						//联行号  对私账户可以不传,对公账户必传  当然对私传了也无所谓  http://posp.cn可做参考
	        
		Map<String, String> data = null;
		try {
			//生成sign, 并转Map<String,Object> 为Map<String,String>
			data = TfcpayUtil.flattenParamsAndSign(pay, KEY);
			//发送HTTP请求
			String result = HttpUtil.post(Constants.DEFRAY_URL, data);
			System.out.println("代付申请请求返回内容如下:\n" + result);
			//将返回结果的JSON字符串转为Map方便取数据
			Map<String, String> resultMap = TfcpayUtil.parseResult(result);
			//根据返回的内容进行业务处理
			bussinessHandle(resultMap);
		} catch (IOException e) {
			System.out.println("请求异常");
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	
	/**
	 * 业务处理
	 * @param resultMap
	 */
	public static void bussinessHandle(Map<String, String> resultMap) {
		try {
			//对返回结果进行验签  验签失败会丢出异常
			TfcpayUtil.VerifySign(resultMap, KEY);
			//如果代码执行到这里说明验签成功
			String code = resultMap.get("code");
			String resultCode = resultMap.get("resultCode");
			if ("SUCCESS".equals(code) && "SUCCESS".equals(resultCode)) {
				// 业务正常，巴拉巴拉获取想要的内容
				System.out.println("----------------正常业务输出-------------");
				System.out.println("内容\n" + JSONObject.toJSONString(resultMap));
				System.out.println("-----------------------------");
				//内容已经有了 要做什么请发挥你的想象力
			}
		} catch (TfcpaySignException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getParam());
			e.printStackTrace();
		}catch (TfcpayBussinessException e) {
			System.out.println("业务异常-------------"+e.getMessage());
			e.printStackTrace();
		}
	}

}
