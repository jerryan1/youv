package com.tfcpay.demo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.exception.TfcpayBussinessException;
import com.tfcpay.exception.TfcpaySignException;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;

/**
 * 商户报备[新]相关示例  
 * 该实例程序演示了商户报备接口的调用,用于完成机构商户下二级商户的注册 <br>
 * 开发者需要填写 mid 和 key 及其它参数信息 <br>
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑 <br>
 * 注意事项:  <br>
 * 1.mid请使用机构商户号 <br>
 * 2.参数extendParams是标准的JSONObject字符串,其中value值为JSONArray <br>
 * 3.该Demo仅供参考 <br>
 * 4.该接口示例与 {@link com.tfcpay.demo.RegisterTest} 属于同一用途 只不过此接口是因为业务发展增加了新的字段 <br>
 * 5.接口业务成功后会返回该机构商户下的二级商户信息 发起交易时使用返回的merchantId和encryptKey进行交易   报备使用的机构商户号是不能交易的! <br>
 */
public class RegisterNewTest {

	
	public static void main(String[] args) {
		registerNew();
	}
	
	
	private static void registerNew(){
		Map<String, Object> data = new HashMap<String, Object>();
		// 机构商户号
		data.put("mid", Constants.AGENT_MID);
		// 商户名称
		data.put("merchantName", "demo:registerNew测试商户");
		// 商户简称
		data.put("merchantAlias", "demo:registerNew测试商户");
		//省编码
		data.put("province", "110000");
		//市编码
		data.put("city", "110100");
		//区县编码
		data.put("county", "110101");
		//商户地址
		data.put("address", "tfcpay-java:registerNew测试地址");
		//商户邮箱
		data.put("merchantEmail", "test@163.com");
		//商户营业类型编号	00：三证合一，01：企业法人，02：个体工商户，03：个人独资企业，04：合伙企业，05：农民专业合作社，06：事业单位商户，07：个人商户
		data.put("licenceType", "02");
		//营业执照号码				非个人商户时必填
		data.put("businessLicense", "1000000000");
		//法人姓名				个人用户请填写身份证姓名
		data.put("legalPersonName", "李某某");
		//法人身份证				个人用户请填写身份证号
		data.put("legalPersonId", "420500198801018877");
		//联系人姓名
		data.put("businessContact", "张某某");
		//联系人电话
		data.put("businessPhone", "13600000000");
		//结算类型，4为D0 ，1为T1
		data.put("settleMode", "1");
		//微信经营类目
		data.put("wechatCategory", "203");
		//支付宝经营类目
		data.put("alipayCategory", "2016062900190116");
		//QQ钱包经营类目
		data.put("qqCategory", "Q000031");
		//银行卡号
		data.put("bankCard", "6226122111111111111");
		//联行号
		data.put("bankLinked", "102100020794");
		//卡账户类型 01 个人 02 企业
		data.put("cardAccountType", "01");
		//信用卡号
		data.put("creditBankCard", "6222111111111111111");
		//信用卡联行号
		data.put("creditBankLinked", "102100020794");
		//扩展参数
		//data.put("extendParams", "{\"03\":[{\"01\":\"0.1\"}],\"04\":[{\"01\":\"0.1\"}],\"00\":[{\"D0\":\"0.2\"},{\"T1\":\"0.1\"}]}");
		data.put("extendParams", extendParamsBuilder());
		// 随机字符串
		data.put("noise", TfcpayUtil.nextUUID());
		
		Map<String, String> registerMap = null;
		try {
			//生成sign, 并转Map<String,Object> 为Map<String,String>
			registerMap = TfcpayUtil.flattenParamsAndSign(data, Constants.AGENT_KEY);
			//发送HTTP请求
			String result = HttpUtil.post(Constants.MERCHANT_REGISTER_NEW_URL, registerMap);
			System.out.println("商户进件[新]返回内容如下:\n" + result);
			//将返回结果的JSON字符串转为Map方便取数据
			Map<String, String> resultMap = TfcpayUtil.parseResult(result);
			//根据返回的内容进行业务处理
			bussinessHandle(resultMap);
		} catch (IOException e) {
			System.out.println("请求异常");
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	
	
	/**
	 * 扩展参数的构造 供参考 具体值需要看开通什么 再做相应修改  可咨询技术
	 */
	private static String extendParamsBuilder(){
		JSONObject extendParams = new JSONObject();
		
		//-- 构造微信扫码
		JSONArray wechatArray = new JSONArray();     
		JSONObject wechat =  new JSONObject();
		wechat.put("01", "0.1");						//01为支付方式 对应的扫码 值为费率
		wechatArray.add(wechat);
		extendParams.put("03", wechatArray);    		//03为支付种类 对应的是微信
		
		//-- 构造支付宝扫码
		JSONArray alipayArray = new JSONArray();     
		JSONObject alipay =  new JSONObject();
		alipay.put("01", "0.1");						//01为支付方式 对应的扫码 值为费率
		alipayArray.add(alipay);
		extendParams.put("04", alipayArray);    		//04为支付种类 对应的是支付宝
		
		//-- 构造代付
		JSONArray defrayArray = new JSONArray();     
		JSONObject defrayD0 =  new JSONObject();
		JSONObject defrayT1 =  new JSONObject();
		defrayD0.put("D0", "0.2");						//D0费率
		defrayT1.put("T1", "0.2");						//T1费率
		defrayArray.add(defrayD0);
		defrayArray.add(defrayT1);
		extendParams.put("00", defrayArray);    		//00代表代付相关
		
		String extendsParamsStr = JSON.toJSONString(extendParams);
		System.out.println("扩展参数字符串:" + extendsParamsStr);
		return extendsParamsStr;
	}
	
	
	
	/**
	 * 业务处理
	 * @param resultMap
	 */
	public static void bussinessHandle(Map<String, String> resultMap) {
		try {
			//对返回结果进行验签  验签失败会丢出异常
			TfcpayUtil.VerifySign(resultMap, Constants.AGENT_KEY);
			//如果代码执行到这里说明验签成功
			String code = resultMap.get("code");
			String resultCode = resultMap.get("resultCode");
			if ("SUCCESS".equals(code) && "SUCCESS".equals(resultCode)) {
				// 业务正常，巴拉巴拉获取想要的内容
				System.out.println("----------------正常业务输出-------------");
				System.out.println("内容\n" + JSONObject.toJSONString(resultMap));
				System.out.println("-----------------------------");
				//内容已经有了 要做什么请发挥你的想象力
				System.out.println("进件返回的mid:"+resultMap.get("merchantId") + " 密钥:"+resultMap.get("encryptKey"));
			}
		} catch (TfcpaySignException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getParam());
			e.printStackTrace();
		}catch (TfcpayBussinessException e) {
			System.out.println("业务异常-------------"+e.getMessage());
			e.printStackTrace();
		}
	}
	
}
