package com.tfcpay.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.exception.TfcpayBussinessException;
import com.tfcpay.exception.TfcpaySignException;
import com.tfcpay.util.TfcpayUtil;
/**
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可根据自己网站需求按照技术文档编写, 并非一定要使用该代码。
 * 接入支付在线文档地址：https://open.tfcpay.com 
 * 该代码仅供学习和研究 使用，仅供参考。
 */
public class Notify extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public Notify() {
        // TODO Auto-generated constructor stub
    }
	
	protected void doPost(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		
		
		Map<String, String> params=TfcpayUtil.requestMaptoMap(req.getParameterMap());
		System.out.println("获取到tfcpay通知信息:\n" + JSON.toJSONString(params));
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		try {
			
			//记得要修改这里的Constants.KEY和本次demo中的商户秘钥一直，否则会验签失败!!!!!!
			if(TfcpayUtil.VerifySign(params, Constants.KEY)){
				System.out.println("验签成功");
				JSONObject result=new JSONObject();
				result.put("code", "SUCCESS");
				result.put("msg", "ok");
				out.println(result.toString());
			}
		} catch (TfcpaySignException e) {
			e.printStackTrace();
			
		}catch (TfcpayBussinessException e) {
			System.out.println("业务异常-------------"+e.getMessage());
			e.printStackTrace();
		}
		
		
		
		
	}

}
