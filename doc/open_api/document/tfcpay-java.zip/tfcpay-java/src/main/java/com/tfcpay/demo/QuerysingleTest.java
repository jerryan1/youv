package com.tfcpay.demo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.tfcpay.config.Constants;
import com.tfcpay.exception.TfcpayBussinessException;
import com.tfcpay.exception.TfcpaySignException;
import com.tfcpay.util.HttpUtil;
import com.tfcpay.util.TfcpayUtil;

/**
 * 支付订单查询 相关示例
 * 该实例程序演示了单笔订单查询接口的调用，验签和业务返回基本处理。
 * 开发者需要在config/Constants 配置 MID 和 KEY，
 * 此示例仅供参考，真实生产需谨慎判断业务逻辑
 *
 */
public class QuerysingleTest {

	public static void main(String[] args) {
		// 订单查询
		querySingle();
	}


	public static void querySingle() {
		//商户密钥
		String singKey = Constants.KEY;
		Map<String, Object> pay = new HashMap<>();
		// 商户号，通过配置获取，只做参考
		pay.put("mid", Constants.MID);
		// 订单号(这里输入您需要查询的订单号)
		pay.put("orderNo", "ed89e728ebc048edbb51571f847f0454"); 
		// 随机字符串
		pay.put("noise", TfcpayUtil.nextUUID());
		Map<String, String> data = null;
		try {
			//生成sign, 并转Map<String,Object> 为Map<String,String>
			data = TfcpayUtil.flattenParamsAndSign(pay, singKey);
			//发送HTTP请求
			String result = HttpUtil.post(Constants.QUERY_SINGLE_URL, data);
			System.out.println("单笔订单查询请求返回内容如下:\n" + result);
			//将返回结果的JSON字符串转为Map方便取数据
			Map<String, String> resultMap = TfcpayUtil.parseResult(result);
			//根据返回的内容进行业务处理
			bussinessHandle(resultMap);
		} catch (IOException e) {
			System.out.println("请求异常");
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	
	/**
	 * 业务处理
	 * @param resultMap
	 */
	public static void bussinessHandle(Map<String, String> resultMap) {
		try {
			//对返回结果进行验签  验签失败会丢出异常
			TfcpayUtil.VerifySign(resultMap, Constants.KEY);
			//如果代码执行到这里说明验签成功
			String code = resultMap.get("code");
			String resultCode = resultMap.get("resultCode");
			if ("SUCCESS".equals(code) && "SUCCESS".equals(resultCode)) {
				// 业务正常，巴拉巴拉获取想要的内容
				System.out.println("----------------正常业务输出-------------");
				System.out.println("内容\n" + JSONObject.toJSONString(resultMap));
				System.out.println("-----------------------------");
				//内容已经有了 要做什么请发挥你的想象力
			}
		} catch (TfcpaySignException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getParam());
			e.printStackTrace();
		}catch (TfcpayBussinessException e) {
			System.out.println("业务异常-------------"+e.getMessage());
			e.printStackTrace();
		}
	}

}
