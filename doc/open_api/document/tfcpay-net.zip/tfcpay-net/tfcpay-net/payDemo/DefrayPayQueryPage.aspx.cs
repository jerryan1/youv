﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using tfcpay;
using tfcpay.business;
using tfcpay.lib;

namespace payDemo
{
    public partial class DefrayPayQueryPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                //代付：商户号,同扫码商户号
                mid.Text = WxPayConfig.qrcodePayMid;
                // 订单号 根据当前时间生成20位随机字符串
                orderNo.Text = ConfigurationManager.AppSettings["Defray_Query_OrderNo"].ToString();
                //生成20随机字符串
                Random ran = new Random();
                int randKey1 = ran.Next(100, 999);
                string time = DateTime.Now.ToString("yyyyMMddHHmmssfff");//获取当前系统时间                
                noise.Text = RandomData.GenerateRandomNumber(20);
            }
        }


        protected void submit_Click(object sender, EventArgs e)
        {
            //<!--* * 通知地址,运行本项目起来以后会有一个接受通知的测试，请修改为外网可访问地址 -->
            string notifyUrl = ConfigurationManager.AppSettings["NotifyUrl"].ToString();
            //<!--*测试地址-->
            string dev_Domain = ConfigurationManager.AppSettings["Dev_Domain"].ToString();
            //<!--代付查询地址-->
            string defray_Query_Url = dev_Domain + ConfigurationManager.AppSettings["Defray_Query_Url"].ToString();
            //请求地址
            string url = defray_Query_Url;
            //商户密钥，同扫码商户密钥
            string key = WxPayConfig.qrcodePayKey;

            WxPayData data = new WxPayData();
            data.SetValue("mid", mid.Text);// 商户号
            data.SetValue("orderNo", orderNo.Text);//订单号
            data.SetValue("noise", noise.Text);//随机字符串,不长于32位

            //调用代付,如果内部出现异常则在页面上显示异常原因
            string requestStr = data.ToUrl();
            Response.Write("<span style='color:#00CD00;font-size:20px'>" + "请求URL地址：" + url + "</span>");
            Response.Write("<span style='color:#00CD00;font-size:20px'>" + "<br />请求内容：" + "</span>");
            Response.Write("<span style='color:#00CD00;font-size:20px'>" + data.ToJsonString() + "</span>");

            //调用刷卡支付,如果内部出现异常则在页面上显示异常原因
            try
            {
                string result = DefrayPay.Run(data, url, key);
                Response.Write("<span style='color:#00CD00;font-size:20px'>" + "<br />----------------正常业务输出-------------" + "</span>");
                Response.Write("<span style='color:#00CD00;font-size:20px'>" + "<br />返回内容：" + "</span>");
                Response.Write("<span style='color:#00CD00;font-size:20px'>" + result + "</span>");
            }
            catch (WxPayException ex)
            {
                Response.Write("<span style='color:#FF0000;font-size:20px'>" + ex.ToString() + "</span>");
            }
            catch (Exception ex)
            {
                Response.Write("<span style='color:#FF0000;font-size:20px'>" + ex.ToString() + "</span>");
            }
        }

        protected void submitBackDefault_Click(object sender, EventArgs e)
        {
            //返回首页
            Server.Transfer("..//default.aspx");
        }
    }
}