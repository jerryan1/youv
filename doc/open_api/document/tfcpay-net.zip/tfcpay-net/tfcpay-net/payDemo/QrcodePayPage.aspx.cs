﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using tfcpay.business;
using tfcpay.lib;

namespace tfcpay.payDemo
{
    /// <summary>
    /// 支付方式：扫码支付Demo
    /// payWayName:QrcodePay
    /// </summary>
    public partial class QrcodePayPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //商户号
                //mid.Text = ConfigurationManager.AppSettings["Mid"].ToString();
                mid.Text = WxPayConfig.qrcodePayMid;
                Random ran = new Random();
                int randKey1 = ran.Next(100, 999);
                string time = DateTime.Now.ToString("yyyyMMddHHmmssfff");//获取当前系统时间
                // 订单号 根据当前时间生成20位随机字符串
                orderNo.Text = time + randKey1;
                //通知地址
                notifyUrl.Text = ConfigurationManager.AppSettings["NotifyUrl"].ToString();
                //生成20随机字符串
                noise.Text = RandomData.GenerateRandomNumber(20);
            }
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            //<!--*测试地址-->
            string dev_Domain = ConfigurationManager.AppSettings["Dev_Domain"].ToString();
            //<!--扫码支付地址-->
            string qrcodePay_Url = dev_Domain + ConfigurationManager.AppSettings["PayCode_Url"].ToString();
            //请求地址
            string url = qrcodePay_Url;         
            //商户密钥
            string key = WxPayConfig.qrcodePayKey;         

            WxPayData data = new WxPayData();      
            
            data.SetValue("mid", mid.Text);// 商户号
            data.SetValue("orderNo", orderNo.Text);//订单号
            data.SetValue("subject", subject.Text);//订单标题
            data.SetValue("body", body.Text);//订单描述
            data.SetValue("amount",amount.Text);//订单金额
            data.SetValue("type", payType.Text);//支付类型
            data.SetValue("notifyUrl", notifyUrl.Text);//消息通知地址
            data.SetValue("noise", noise.Text);//随机字符串         


            //调用刷卡支付,如果内部出现异常则在页面上显示异常原因
            string requestStr = data.ToUrl();
            Response.Write("<span style='color:#00CD00;font-size:20px'>" + "请求URL地址：" + url + "</span>");
            Response.Write("<span style='color:#00CD00;font-size:20px'>" + "<br />请求内容：" + "</span>");
            Response.Write("<span style='color:#00CD00;font-size:20px'>" + data.ToJsonString() + "</span>");

            try
            {
                string result = QrcodePay.Run(data, url, key);
                Response.Write("<span style='color:#00CD00;font-size:20px'>" + "<br />----------------正常业务输出-------------" + "</span>");
                Response.Write("<span style='color:#00CD00;font-size:20px'>" + "<br />返回内容：" + "</span>");
                Response.Write("<span style='color:#00CD00;font-size:20px'>" + result + "</span>");
            }
            catch (WxPayException ex)
            {
                Response.Write("<span style='color:#FF0000;font-size:20px'>" + ex.ToString() + "</span>");
            }
            catch (Exception ex)
            {
                Response.Write("<span style='color:#FF0000;font-size:20px'>" + ex.ToString() + "</span>");
            }
        }

        protected void submitBackDefault_Click(object sender, EventArgs e)
        {
            //返回首页
            Server.Transfer("..//default.aspx");
        }
    }
}