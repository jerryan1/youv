﻿using System;
using System.Collections.Generic;
using System.Web;
using tfcpay.lib;

namespace tfcpay.business
{
    public class DefrayPay
    {
        /**
        * 代付完整业务流程逻辑
        * @param url 请求地址
        * @param key 商户密钥
        * @throws WxPayException
        * @return 代付结果
        */
        public static string Run(WxPayData data, string url, string key)
        {
            Log.NewInfo("DefrayPay", "DefrayPay is processing...");

            WxPayData result = DemoPayApi.Demopay(data, url, key); //提交代付请求，接收返回结果

            //如果代付接口调用失败，则抛异常
            if (!result.IsSet("code") || result.GetValue("code").ToString() == "FAIL")
            {
                string returnMsg = result.IsSet("return_msg") ? result.GetValue("return_msg").ToString() : "";
                Log.NewError("DefrayPay", "DefrayPay API interface call failure, result : " + result.ToXml());
                throw new WxPayException("DefrayPay API interface call failure, return_msg : " + returnMsg);
            }

            //签名验证
            IDictionary<string, string> dicObj = result.ToDictionaryObj();
            result.NewCheckSign(dicObj, key);
            Log.Debug("DefrayPay", "DefrayPay response check sign success");

            //代付成功，将返回内容转换成JSon字符串，显示在web页面
            if (result.GetValue("code").ToString() == "SUCCESS" && result.GetValue("resultCode").ToString() == "SUCCESS")
            {
                Log.Debug("DefrayPay", "DefrayPay business success, result : ToJson-----" + result.ToJson());
                return result.ToJsonString();
            }

            //代付没有成功，将返回内容转换指定格式，显示在web页面
            return result.ToPrintStr();
        }

    }
}