﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Web;
using tfcpay.lib;

namespace tfcpay.business
{
    public class BrushCardPay
    {
        /**
        * 刷卡支付完整业务流程逻辑
        * @param url 请求地址
        * @param key 商户密钥
        * @throws WxPayException
        * @return 刷卡支付结果
        */
        public static string Run(WxPayData data, string url, string key)
        {
            Log.NewInfo("BrushCardPay", "BrushCardPay is processing...");

            WxPayData result = DemoPayApi.Demopay(data, url, key); //提交被扫支付，接收返回结果

            //如果提交被扫支付接口调用失败，则抛异常
            if (!result.IsSet("code") || result.GetValue("code").ToString() == "FAIL")
            {
                string returnMsg = result.IsSet("return_msg") ? result.GetValue("return_msg").ToString() : "";
                Log.NewError("MicroPay", "Micropay API interface call failure, result : " + result.ToXml());
                throw new WxPayException("Micropay API interface call failure, return_msg : " + returnMsg);
            }

            //签名验证
            IDictionary<string, string> dicObj = result.ToDictionaryObj();
            result.NewCheckSign(dicObj, key);
            Log.Debug("BrushCardPay", "BrushCardPay response check sign success");

            //刷卡支付成功，，将返回内容转换成JSon字符串，显示在web页面
            if (result.GetValue("code").ToString() == "SUCCESS" && result.GetValue("resultCode").ToString() == "SUCCESS")
            {
                Log.Debug("BrushCardPay", "BrushCardPay business success, result : ToJson-----" + result.ToJson());
                return result.ToJson();
            }

            //刷卡支付没有成功，将返回内容转换指定格式，显示在web页面
            return result.ToPrintStr();
        }

    }
}