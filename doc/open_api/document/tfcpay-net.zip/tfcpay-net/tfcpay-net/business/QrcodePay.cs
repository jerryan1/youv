﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Web;
using tfcpay.lib;

namespace tfcpay.business
{
    public class QrcodePay
    {
        /**
        * 扫码支付完整业务流程逻辑
        * @param url 请求地址
        * @param key 商户密钥
        * @throws WxPayException
        * @return 刷卡支付结果
        */
        public static string Run(WxPayData data, string url, string key)
        {
            Log.NewInfo("QrcodePay", "QrcodePay is processing...");
            
            WxPayData result = DemoPayApi.Demopay(data, url, key); //提交被扫支付，接收返回结果
            
            //如果提交被扫支付接口调用失败，则抛异常  {"code":"FAIL","msg":"验签失败"}
            if (result.GetValue("code").ToString() == "FAIL")
            {
                string returnMsg = result.IsSet("msg") ? result.GetValue("msg").ToString() : "";
                Log.NewError("QrcodePay", "QrcodePay API interface call failure, result : " + result.ToXml());
                throw new WxPayException("Micropay API interface call failure, return_msg : " + returnMsg);
            }

            //签名验证
            IDictionary<string, string> dicObj = result.ToDictionaryObj();
            result.NewCheckSign(dicObj, key);
            Log.Debug("QrcodePay", "QrcodePay response check sign success");

            //扫码支付成功，将返回内容转换成JSon字符串，显示在web页面
            if (result.GetValue("code").ToString() == "SUCCESS" && result.GetValue("resultCode").ToString() == "SUCCESS")
            {
                Log.Debug("QrcodePay", "QrcodePay business success, result : ToJson-----" + result.ToJson());
                return result.ToJson();
            }

            //扫码支付没有成功，将返回内容转换指定格式，显示在web页面
            return result.ToPrintStr();
        }

    }
}