﻿using System;
using System.Collections.Generic;
using System.Web;

namespace tfcpay.lib
{
    public class RandomData
    {
        private static char[] constant = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

        public static string GenerateRandomNumber(int Length)
        {
            System.Text.StringBuilder newRandom = new System.Text.StringBuilder(16);
            Random rd = new Random();
            for (int i = 0; i < Length; i++)
            {
                newRandom.Append(constant[rd.Next(16)]);
            }
            //f036d 2a89b 904ed c8ea6 f76b6 9d950 47  32位
            return newRandom.ToString();
        }
    }
}