﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Xml;
using System.Security.Cryptography;
using System.Text;
using LitJson;
using System.Collections;

namespace tfcpay
{
    /// <summary>
    /// 微信支付协议接口数据类，所有的API接口通信都依赖这个数据结构，
    /// 在调用接口之前先填充各个字段的值，然后进行接口通信，
    /// 这样设计的好处是可扩展性强，用户可随意对协议进行更改而不用重新设计数据结构，
    /// 还可以随意组合出不同的协议数据包，不用为每个协议设计一个数据包结构
    /// </summary>
    public class WxPayData
    {
        public WxPayData()
        {
            m_values = new SortedDictionary<string, object>();
        }

        //采用排序的Dictionary的好处是方便对数据包进行签名，不用再签名之前再做一次排序
        private SortedDictionary<string, object> m_values = new SortedDictionary<string, object>();

        /**
        * 设置某个字段的值
        * @param key 字段名
         * @param value 字段值
        */
        public void SetValue(string key, object value)
        {
            m_values[key] = value;
        }

        /**
        * 根据字段名获取某个字段的值
        * @param key 字段名
         * @return key对应的字段值
        */
        public object GetValue(string key)
        {
            object o = null;
            m_values.TryGetValue(key, out o);
            return o;
        }

        /**
         * 判断某个字段是否已设置
         * @param key 字段名
         * @return 若字段key已被设置，则返回true，否则返回false
         */
        public bool IsSet(string key)
        {
            object o = null;
            m_values.TryGetValue(key, out o);
            if (null != o)
                return true;
            else
                return false;
        }

        /**
        * @将Dictionary转成xml
        * @return 经转换得到的xml串
        * @throws WxPayException
        **/
        public string ToXml()
        {
            //数据为空时不能转化为xml格式
            if (0 == m_values.Count)
            {
                Log.Error(this.GetType().ToString(), "WxPayData数据为空!");
                throw new WxPayException("WxPayData数据为空!");
            }

            string xml = "<xml>";
            foreach (KeyValuePair<string, object> pair in m_values)
            {
                //字段值不能为null，会影响后续流程
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Value.GetType() == typeof(int))
                {
                    xml += "<" + pair.Key + ">" + pair.Value + "</" + pair.Key + ">";
                }
                else if (pair.Value.GetType() == typeof(string))
                {
                    xml += "<" + pair.Key + ">" + "<![CDATA[" + pair.Value + "]]></" + pair.Key + ">";
                }
                else//除了string和int类型不能含有其他数据类型
                {
                    Log.Error(this.GetType().ToString(), "WxPayData字段数据类型错误!");
                    throw new WxPayException("WxPayData字段数据类型错误!");
                }
            }
            xml += "</xml>";
            return xml;
        }

        /**
        * @将xml转为WxPayData对象并返回对象内部的数据
        * @param string 待转换的xml串
        * @return 经转换得到的Dictionary
        * @throws WxPayException
        */
        public SortedDictionary<string, object> FromXml(string xml)
        {
            if (string.IsNullOrEmpty(xml))
            {
                Log.Error(this.GetType().ToString(), "将空的xml串转换为WxPayData不合法!");
                throw new WxPayException("将空的xml串转换为WxPayData不合法!");
            }

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xml);
            XmlNode xmlNode = xmlDoc.FirstChild;//获取到根节点<xml>
            XmlNodeList nodes = xmlNode.ChildNodes;
            foreach (XmlNode xn in nodes)
            {
                XmlElement xe = (XmlElement)xn;
                m_values[xe.Name] = xe.InnerText;//获取xml的键值对到WxPayData内部的数据中
            }
			
            try
            {
				//2015-06-29 错误是没有签名
				if(m_values["return_code"] != "SUCCESS")
				{
					return m_values;
				}
                CheckSign();//验证签名,不通过会抛异常
            }
            catch(WxPayException ex)
            {
                throw new WxPayException(ex.Message);
            }

            return m_values;
        }

        /**
        * @Dictionary格式转化成url参数格式
        * @ return url格式串, 该串不包含sign字段值
        */
        public string ToUrl()
        {
            string buff = "";
            foreach (KeyValuePair<string, object> pair in m_values)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Key != "sign" && pair.Value.ToString() != "")
                {
                    buff += pair.Key + "=" + pair.Value + "&";
                }
            }
            buff = buff.Trim('&');
            return buff;
        }

        /**
       * @Dictionary格式转化成url参数格式
       * @ return url格式串, 该串不包含sign字段值
       */
        public string ToUrl(IDictionary<string, string> resultObj)
        {
            //amount=0.02&code=SUCCESS&datetime=20171010142529&mid=812017050323777&msg=ok&noise=ldUHLBB76kMcCCQJ955MPiptCYXfs6Y7&orderNo=61868ca4dedc47caa78239a11a8dc06e
            //&qrCode=weixin://wxpay/bizpayurl?pr=sNb7xGR&resultCode=SUCCESS&type=wechat&ddbax6n4cg8qj958ytt6

            string buff = "";
            foreach (KeyValuePair<string, string> pair in resultObj)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Key != "sign" && pair.Value.ToString() != "")
                {
                    buff += pair.Key + "=" + pair.Value + "&";
                }
            }
            buff = buff.Trim('&');
            return buff;
        }

        /**
        * @Dictionary格式转化成url参数格式
        * @ return url格式串, 该串包含sign字段值
        */
        public string ToFormatString()
        {
            string buff = "";
            foreach (KeyValuePair<string, object> pair in m_values)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Value.ToString() != "")
                {
                    buff += pair.Key + "=" + pair.Value + "&";
                }
            }
            buff = buff.Trim('&');
            return buff;
        }

        /**
        * @Dictionary格式转化成url参数格式
        * @ return url格式串, 该串包含sign字段值
        */
        public string ToFormatString(IDictionary<string, string> resultObj)
        {
            string buff = "";
            foreach (KeyValuePair<string, string> pair in resultObj)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Value.ToString() != "")
                {
                    buff += pair.Key + "=" + pair.Value + "&";
                }
            }
            buff = buff.Trim('&');
            return buff;
        }

        /**
        * @Dictionary格式转化成Json参数格式
        * @ return Json格式串, 该串包含sign字段值
        */
        public string ToJsonString()
        {
            int i = 0;
            string buff = "{";
            //char doubleMarks = '"';
            foreach (KeyValuePair<string, object> pair in m_values)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Value.ToString() != "")
                {
                    //buff += pair.Key + "=" + pair.Value + ", ";

                    //每添加6个，换行！
                    i++;
                    if (i % 6 == 0)
                        buff += "<br>";
                    buff += string.Format("\"{0}\":\"{1}\",", pair.Key, pair.Value.ToString());
                }
            }
            buff = buff.Trim(',')+"}";
            return buff;
        }


        /**
        * @WxPayData格式转化成IDictionary<string, string>格式
        * @ return IDictionary<string, string>格式数据
        */
        public IDictionary<string, string> ToDictionaryObj()
        {
            IDictionary<string, string> dicObj = new Dictionary<string, string>(); ;
            foreach (KeyValuePair<string, object> pair in m_values)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                if (pair.Value.ToString() != "")
                {
                    dicObj.Add(pair.Key.ToString(), pair.Value.ToString());
                }
            }

            return dicObj;
        }


        /**
        * @Dictionary格式化成Json
         * @return json串数据
        */
        public string ToJson()
        {
            string jsonStr = JsonMapper.ToJson(m_values);
            return jsonStr;
        }

        public string ToUft8(string unicodeString)
        {
            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] encodedBytes = utf8.GetBytes(unicodeString);
            string decodedString = utf8.GetString(encodedBytes);
            return decodedString;
        }

        /**
        * @Json格式化成Dictionary
        * @return Dictionary数据         
        */
        public WxPayData FromJson(string josn)
        {
            WxPayData result = new WxPayData();
            string[] responseStr1 = josn.Replace("{", "").Replace("}", "").Split(',');
            foreach (string responseStr in responseStr1)
            {
                string[] responseStr2 = responseStr.Split(':');
                if (responseStr2.Length == 2)
                {
                    string key = responseStr2[0].Replace(@"""", "");
                    string value = responseStr2[1].Replace(@"""", "");
                    result.SetValue(key, value);
                }
                else
                {
                    string key = responseStr2[0].Replace(@"""", "");
                    string value = "";
                    //将多删除的":"复原。
                    for (int i = 1; i < responseStr2.Length; i++)
                    {
                        value += responseStr2[i].Replace(@"""", "") + ":";
                    }
                    //去掉最后多余的":"
                    value = value.Trim(':');
                    result.SetValue(key, value);
                }
            }
            return result;
        }


        /**
        * @values格式化成能在Web页面上显示的结果（因为web页面上不能直接输出xml格式的字符串）
        */
        public string ToPrintStr()
        {
            string str = "";
            foreach (KeyValuePair<string, object> pair in m_values)
            {
                if (pair.Value == null)
                {
                    Log.Error(this.GetType().ToString(), "WxPayData内部含有值为null的字段!");
                    throw new WxPayException("WxPayData内部含有值为null的字段!");
                }

                str += string.Format("{0}={1}<br>", pair.Key, pair.Value.ToString());
            }
            Log.Debug(this.GetType().ToString(), "Print in Web Page : " + str);
            return str;
        }

        /**
        * @生成签名，详见签名生成算法
        * @return 签名, sign字段不参加签名
        */
        public string MakeSign()
        {
            //转url格式
            string str = ToUrl();
            //在string后加入API KEY
            str += "&key=" + WxPayConfig.KEY;
            //MD5加密
            var md5 = MD5.Create();
            var bs = md5.ComputeHash(Encoding.UTF8.GetBytes(str));
            var sb = new StringBuilder();
            foreach (byte b in bs)
            {
                sb.Append(b.ToString("x2"));
            }
            //所有字符转为大写
            return sb.ToString().ToUpper();
        }

        /**
        * @生成签名，详见签名生成算法
        * key：商户密钥
        * @return 签名, sign字段不参加签名
        */
        public string NewMakeSign(string key)
        {            
            //转url格式
            string str = ToUrl();
            str += "&" + key;
            //MD5加密
            var md5 = MD5.Create();
            var bs = md5.ComputeHash(Encoding.UTF8.GetBytes(str));
            var sb = new StringBuilder();
            foreach (byte b in bs)
            {
                sb.Append(b.ToString("x2"));
            }
            //所有字符转为大写
            string result = sb.ToString().ToUpper();
            return result;
        }

        /**
        * @生成签名，详见签名生成算法
        * @return 签名, sign字段不参加签名
        */
        public string TestNewMakeSign()
        {
            //验签字符串
            //amount=0.02&body=订单描述&mid=812017050323777&noise=xLws70RUwmFYTajgrffHTg52NAI38uPf&notifyUrl=http://192.168.1.154:8080/tfcpay-java/notify&orderNo=bd8d12bfc0eb43b6be93b49cdd5fd34e&subject=订单标题&type=wechat&ddbax6n4cg8qj958ytt6
            string str1 = "amount=0.16&body=????&mid=812017050323777&noise=24b2a26fb487a300ad81&notifyUrl=http://192.168.1.154:8080/tfcpay-java/notify&orderNo=20171010173630611236&subject=????&type=wechat&ddbax6n4cg8qj958ytt6";
            string str2 = "amount=0.16&body=订单描述&mid=812017050323777&noise=24b2a26fb487a300ad81&notifyUrl=http://192.168.1.154:8080/tfcpay-java/notify&orderNo=20171010173630611236&subject=订单标题&type=wechat&ddbax6n4cg8qj958ytt6";

            //转url格式
            //在string后加入API KEY
            str1 += "&" + WxPayConfig.qrcodePayKey;
            str2 += "&" + WxPayConfig.qrcodePayKey;
            //MD5加密
            var md5 = MD5.Create();
            var bs1 = md5.ComputeHash(Encoding.UTF8.GetBytes(str1));
            var bs2 = md5.ComputeHash(Encoding.UTF8.GetBytes(str2));
            var sb1 = new StringBuilder();
            var sb2 = new StringBuilder();
            foreach (byte b in bs1)
            {
                sb1.Append(b.ToString("x2"));
            }
            foreach (byte b in bs2)
            {
                sb2.Append(b.ToString("x2"));
            }
            //所有字符转为大写
            sb1.ToString().ToUpper();
            sb2.ToString().ToUpper();
            return sb2.ToString().ToUpper();
        }

        /**
        * @生成签名，详见签名生成算法
        * key商户密钥
        * @return 签名, sign字段不参加签名
        */
        public string NewMakeSign(IDictionary<string, string> resultObj, string key)
        {
            //转url格式
            string str = ToUrl(resultObj);
            str += "&" + key;
            //MD5加密
            var md5 = MD5.Create();
            var bs = md5.ComputeHash(Encoding.UTF8.GetBytes(str));
            var sb = new StringBuilder();
            foreach (byte b in bs)
            {
                sb.Append(b.ToString("x2"));
            }
            //所有字符转为大写
            return sb.ToString().ToUpper();
        }

        /**
        * 
        * 检测签名是否正确
        * 正确返回true，错误抛异常
        */
        public bool CheckSign()
        {
            //如果没有设置签名，则跳过检测
            if (!IsSet("sign"))
            {
               Log.Error(this.GetType().ToString(), "WxPayData签名存在但不合法!");
               throw new WxPayException("WxPayData签名存在但不合法!");
            }
            //如果设置了签名但是签名为空，则抛异常
            else if(GetValue("sign") == null || GetValue("sign").ToString() == "")
            {
                Log.Error(this.GetType().ToString(), "WxPayData签名存在但不合法!");
                throw new WxPayException("WxPayData签名存在但不合法!");
            }

            //获取接收到的签名
            string return_sign = GetValue("sign").ToString();

            //在本地计算新的签名
            string cal_sign = MakeSign();

            //签名一致，直接返回
            if (cal_sign == return_sign)
            {
                return true;
            }

            Log.Error(this.GetType().ToString(), "WxPayData签名验证错误!");
            throw new WxPayException("WxPayData签名验证错误!");
        }


        /**
        * 检测签名是否正确
        * 正确返回true，错误抛异常
        */
        public bool NewCheckSign(IDictionary<string, string> resultObj,string key)
        {
            //如果没有设置签名，则跳过检测
            if (!IsSet("sign"))
            {
                Log.Error(this.GetType().ToString(), "WxPayData签名存在但不合法!");
                throw new WxPayException("WxPayData签名存在但不合法!");
            }
            //如果设置了签名但是签名为空，则抛异常
            else if (GetValue("sign") == null || GetValue("sign").ToString() == "")
            {
                Log.Error(this.GetType().ToString(), "WxPayData签名存在但不合法!");
                throw new WxPayException("WxPayData签名存在但不合法!");
            }

            //获取接收到的签名
            string return_sign = GetValue("sign").ToString();

            //在本地计算新的签名
            string cal_sign = NewMakeSign(resultObj, key);
            
            //签名一致，直接返回
            if (cal_sign == return_sign)
            {
                return true;
            }

            string outCode = "";
            string outResultCode = "";
            string outErrCodeDes = "";
            resultObj.TryGetValue("code", out outCode);
            resultObj.TryGetValue("resultCode", out outResultCode);
            resultObj.TryGetValue("errCodeDes", out outErrCodeDes);

            if (outCode.Equals("SUCCESS") && outResultCode.Equals("SUCCESS"))
            {                
                return true;
            }
            else if (outCode.Equals("SUCCESS") && outResultCode.Equals("FAIL"))
            {
                //服务器接受到请求数据，并返回数据,将返回的错误提示写入日志中。
                Log.NewError(this.GetType().ToString(), outErrCodeDes);
                return true;
            }
            
            //Log.Error(this.GetType().ToString(), "WxPayData签名验证错误!");
            throw new WxPayException("WxPayData签名验证错误!");
        }

        /**
        * @获取Dictionary
        */
        public SortedDictionary<string, object> GetValues()
        {
            return m_values;
        }
    }
}