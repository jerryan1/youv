﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Web;

namespace tfcpay.lib
{
    public class DemoPayApi
    {
        /**
        * 提交被扫支付API
        * @param WxPayData inputObj 提交给被扫支付API的参数
        * @param url 请求地址
        * @param key 商户密钥
        * @param int timeOut 超时时间
        * @throws WxPayException
        * @return 成功时返回调用结果，其他抛异常
        */
        public static WxPayData Demopay(WxPayData inputObj, string url, string key, int timeOut = 10)
        {
            //检测必填参数
            if (!inputObj.IsSet("mid"))
            {
                throw new WxPayException("提交被扫支付API接口中，缺少必填参数mid！");
            }
            else if (!inputObj.IsSet("orderNo"))
            {
                throw new WxPayException("提交被扫支付API接口中，缺少必填参数orderNo！");
            }
            //else if (!inputObj.IsSet("amount"))
            //{
            //    throw new WxPayException("提交被扫支付API接口中，缺少必填参数amount！");
            //}
            //else if (!inputObj.IsSet("type"))
            //{
            //    throw new WxPayException("提交被扫支付API接口中，缺少必填参数type！");
            //}
            else if (!inputObj.IsSet("noise"))
            {
                throw new WxPayException("提交被扫支付API接口中，缺少必填参数noise！");
            }

            var start = DateTime.Now;//请求开始时间

            //生成签名
            inputObj.SetValue("sign", inputObj.NewMakeSign(key));

            

            //WxPayData格式转化成Url格式
            string strObj = inputObj.ToFormatString();

            //进行Post请求操作
            string response = HttpService.NewPost(strObj, url, timeOut);
            Log.NewDebug("DemoPayApi", "BrushCardPay response : " + response);
            
            ////WxPayData格式转化成IDictionary<string, string>格式
            //IDictionary<string, string> dicObj = inputObj.ToDictionaryObj();

            ////进行Post请求操作
            //string response = HttpService.CreatePostHttpResponse(url, dicObj, timeOut);
            //Log.NewDebug("DemoPayApi", "BrushCardPay response : " + response);

            var end = DateTime.Now;
            int timeCost = (int)((end - start).TotalMilliseconds);//获得接口耗时

            ////将结果转换为WxPayData对象以返回
            WxPayData result = new WxPayData();
            result = inputObj.FromJson(response);
            
            return result;
        }        
    }
}