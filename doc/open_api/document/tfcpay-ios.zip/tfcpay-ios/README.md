# TFCPAY iOS Demo

### 简介
1. 接口说明以[最新聚融通在线文档](https://open.tfcpay.com/#/open_api/)为准
2. 请以真机测试结果为准

### 版本要求
系统要求8.0及以上版本

### 使用示例
```
1. 使用Xcode打开demo文件夹下的TFCPayDemo.xcworkspace工程
2. 在Xcode编译器的左上角，点击target，选择需要运行的demo工程（target是指显示模拟器类型和运行键中间的那个有图标的东西）
3. 也可直接使用Xcode打开demo文件夹下的demo工程（例如：demo1.xcodeproj）
```

### 示例说明
```
目前提供的demo示例为:
1、快捷支付（同名进出）   —— demo.xcodeproj
2、快捷支付（同名进出）2  —— demo1.xcodeproj
```