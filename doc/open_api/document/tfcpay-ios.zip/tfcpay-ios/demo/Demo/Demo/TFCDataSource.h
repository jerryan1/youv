//
//  TFCDataSource.h
//  Demo
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//
/*
 该类提供了一些数据信息
 titleArray ： 页面展示中Label的标题
 placeholders ：textField的占位符
 bankArray ：银行名、银行编码
 urlArray ：测试环境对应的请求地址
 params：获取签名和请求时会用到的参数名称
 */
#import <Foundation/Foundation.h>

@interface TFCDataSource : NSObject
/** labelTitles */
+ (NSArray *)titleArray;
/** placeholders */
+ (NSArray *)placeholders;
/** banks */
+ (NSArray *)bankArray;
/** urls */
+ (NSArray *)urlArray;
/** params */
+ (NSArray *)params;
@end
