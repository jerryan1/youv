//
//  TFCDataSource.m
//  Demo
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//

#import "TFCDataSource.h"

@implementation TFCDataSource

+ (NSArray *)titleArray
{
    NSArray *titleArray = @[@"请求URL",@"商户号",@"通知URL",@"订单号",@"商品名称",@"商品描述",@"交易金额",@"付款人银行卡",@"费率",@"固定金额",@"收款人银行卡",@"收款人身份证",@"收款人手机号",@"收款人银行",@"收款人姓名",@"备注",@"秘钥"];
    return titleArray;
}

+ (NSArray *)placeholders
{
    NSArray *placeholders = @[@"请选择或输入URL",@"请输入商户号",@"请输入通知URL",@"请输入订单号",@"请输入商品名称",@"请输入商品描述",@"请输入交易金额",@"请输入付款人银行卡号",@"请输入费率",@"请输入固定金额",@"请输入收款人银行卡号",@"请输入收款人身份证号",@"请输入收款人手机号",@"请选择收款人银行",@"请输入收款人姓名",@"请输入备注",@"请输入秘钥"];
    return placeholders;
}

+ (NSArray *)bankArray
{
    NSArray *bankArray = @[@{@"中国工商银行":@"102"},
                           @{@"中国农业银行":@"103"},
                           @{@"中国银行":@"104"},
                           @{@"中国建设银行":@"105"},
                           @{@"中信银行":@"106"},
                           @{@"兴业银行":@"309"},
                           @{@"中国邮政储蓄银行":@"403"},
                           @{@"招商银行":@"310"},
                           @{@"光大银行":@"330"},
                           @{@"平安银行":@"340"},
                           @{@"交通银行":@"350"},
                           @{@"民生银行":@"360"},
                           @{@"北京银行":@"370"},
                           @{@"华夏银行":@"380"},
                           @{@"南京银行":@"390"},
                           @{@"东亚银行":@"400"},
                           @{@"浦发银行":@"410"},
                           @{@"上海银行":@"420"},
                           @{@"兰州银行":@"430"},
                           @{@"徽商银行":@"440"},
                           @{@"青岛银行":@"450"},
                           @{@"浙商银行":@"460"},
                           @{@"国家开发银行":@"470"},
                           @{@"中国进出口银行":@"480"},
                           @{@"中国农业发展银行":@"490"},
                           @{@"广东发展银行":@"500"},
                           @{@"渤海银行股份有限公司":@"510"}];
    return bankArray;
}

+ (NSArray *)urlArray
{
    NSArray *urlArray = @[
                       @{@"测试环境":@"http://192.168.9.121/v2/quickPay/mobilePay"},
                       @{@"测试环境合伙人":@"http://192.168.9.81/v2/quickPay/mobilePay"},
                       @{@"商户测试环境":@"https://devapi.tfcpay.com/v2/quickPay/mobilePay"},
                       @{@"准生产测试环境":@"https://zdevapi.tfcpay.com/v2/quickPay/mobilePay"},
                       @{@"准生产测试环境合伙人":@"http://172.16.102.15:8082/quickPay/mobilePay"},
                       @{@"生产测试环境":@"https://api.tfcpay.com/v2/quickPay/mobilePay"},
                       @{@"生产测试环境合伙人":@"http://203.81.244.127/v2/quickPay/mobilepay"}];
    return urlArray;
}

+ (NSArray *)params
{
    /*
     字段介绍
     urlString:请求地址
     mid:商户号
     notifyUrl:针对该交易的交易状态同步通知接受URL(如不填写,则收不到通知)
     orderNo:合作伙伴交易号（确保在合作伙伴系统中唯一）
     amount:交易的总金额，单位为元
     subject:商品的标题
     body:商品的具体描述
     bankCardNo:付款方银行卡号
     feeRate:费率，不带百分号如果费率为0.4% 则传0.4
     mustAmt:固定金额
     receivedCardNo:收款方银行卡号
     receivedCardId:收款方身份证号
     receivedPhoneNo:收款方手机号码
     receivedBankCode:收款方银行编码
     receivedRealName:收款方银行卡开户名
     remark:备注 （可以为空）
     secretKey: md5加密秘钥
     noise: 随机字符串,不长于32位
     sign:数据的加密校验字符串，目前只支持使用MD5签名算法对待签名数据进行签名
     cardType: 卡类标识 02（信用卡）
     */
    NSArray *params = @[@"urlString",@"mid",@"notifyUrl",@"orderNo",@"subject",@"body",@"amount",@"bankCardNo",@"feeRate",@"mustAmt",@"receivedCardNo",@"receivedCardId",@"receivedPhoneNo",@"receivedBankCode",@"receivedRealName",@"remark",@"secretKey",@"cardType",@"noise"];
    
    return params;
}
@end
