//
//  ViewController.m
//  Demo
//
//  Created by ccy on 2017/9/25.
//  Copyright © 2017年 ccy. All rights reserved.
//
/*
 需要在该页面填写请求数据
 页面中的字段，除了备注（remark）字段，其余均不可为空
 测试支付参数以我方提供的为准
 */

#import "ViewController.h"
#import "YJAlertListView.h"
#import "TFCDataSource.h"
#import "TFCHttpRequest.h"
#import "MBProgressHUD+YJMethod.h"
#import "TFCUtils.h"
#import "TFCFactory.h"
#import "TFCMacros.h"
#import "UPPaymentControl.h"

#define INFO_KEY @"info_key"

@interface ViewController ()<YJAlertListViewDelegate, YJAlertListViewDatasource, UITextFieldDelegate>
@property (nonatomic, strong) NSIndexPath *selectedIndexPath;
/** YJAlertListView 数据源 */
@property (nonatomic, strong)  NSArray *listDataSource;
/** YJAlertListView */
@property (nonatomic, strong)  YJAlertListView *listView;
/** scrollView */
@property (nonatomic, strong)  UIScrollView *scrollView;
@end

@implementation ViewController {
    UITextField * _urlTf;
    UITextField * _bankTf;
    NSString * _urlString; //请求地址
    NSString * _bankCode; //银行编码
    NSString * _secretKey; //秘钥
    NSArray * _textInfo;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    UITextField *tf = [self.scrollView viewWithTag:99 + 3];
    tf.text = [TFCUtils timeStamp];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
}

- (void)createUI {
    CGFloat labelWidth = 100.f;
    CGFloat buttonWidth = 44.f;
    CGFloat margin = 10.f;
    CGFloat height = 44.f;
    CGFloat topBar = STATUS_BAR_HEIGHT + NAVIGATION_BAR_HEIGHT;
    NSArray * titleArray = [TFCDataSource titleArray];
    NSArray * placeholders = [TFCDataSource placeholders];
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    NSArray *payInfo;
    if ([[TFCUtils valueForKey:INFO_KEY] count] == titleArray.count) {
        payInfo = [TFCUtils valueForKey:INFO_KEY];
    }
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, topBar, SCREEN_WIDTH, SCREEN_HEIGHT - height - topBar)];
    scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, titleArray.count * height + 248);
    scrollView.showsHorizontalScrollIndicator = NO;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [scrollView addGestureRecognizer:tap];
    self.scrollView = scrollView;
    [self.view addSubview:scrollView];
    
    for (int i = 0; i < titleArray.count; i++) {
        UILabel *label = [TFCFactory labelWithFrame:CGRectMake(margin, height * i + margin, labelWidth, height) text:titleArray[i] textColor:nil fontName:nil fontSize:15 center:NO];
        [scrollView addSubview:label];
        UITextField *textField = [TFCFactory textFieldWithFrame:CGRectMake(labelWidth + margin, height * i + margin, SCREEN_WIDTH - labelWidth - margin, height) placeholder:placeholders[i] text:nil borderStyle:0 backgroundColor:nil delegate:self];
        textField.tag = 99 + i;
        [scrollView addSubview:textField];
        if (i == 0) {
            //请求url 相关的
            textField.frame = CGRectMake(labelWidth + margin, height * i + margin, SCREEN_WIDTH - labelWidth - margin - buttonWidth, height);
            if (payInfo.count > 0) {
                textField.text = payInfo[i];
            }
            
            _urlTf = textField;
            UIButton *button = [TFCFactory buttonWithFrame:CGRectMake(SCREEN_WIDTH - buttonWidth, height * i + margin, buttonWidth, height) title:@"选择" titleColor:[UIColor whiteColor] highlighted:YES highlightedColor:[UIColor grayColor]];
            button.backgroundColor = TFCCOLOR(0x00c3cd);
            [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
            button.tag = 10;
            [scrollView addSubview:button];
        }else if (i == 13) {
            //银行相关的
            textField.frame = CGRectMake(labelWidth + margin, height * i + margin, SCREEN_WIDTH - labelWidth - margin - buttonWidth, height);
            _bankTf = textField;
            UIButton *button = [TFCFactory buttonWithFrame:CGRectMake(SCREEN_WIDTH - buttonWidth, height * i + margin, buttonWidth, height) title:@"选择" titleColor:[UIColor whiteColor] highlighted:YES highlightedColor:[UIColor grayColor]];
            button.backgroundColor = TFCCOLOR(0x00c3cd);
            [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
            button.tag = 11;
            [scrollView addSubview:button];
        }else {
            if (payInfo.count > 0) {
                if (i != 3 ) {
                    textField.text = payInfo[i];
                }
            }
        }
        //添加一个分隔线
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(textField.frame.origin.x, textField.frame.origin.y + textField.frame.size.height - 1, textField.frame.size.width, 1)];
        lineView.backgroundColor = [UIColor grayColor];
        [scrollView addSubview:lineView];
    }
    //支付按钮
    UIButton *button = [TFCFactory buttonWithFrame:CGRectMake(0, SCREEN_HEIGHT - height, SCREEN_WIDTH, height) title:@"支付" titleColor:[UIColor whiteColor] fontName:nil fontSize:17 highlighted:YES highlightedColor:[UIColor grayColor]];
    button.backgroundColor = TFCCOLOR(0x00c3cd);
    [button addTarget:self action:@selector(payAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}
//选择URL或者Bank的按钮被点击
- (void)buttonClicked:(UIButton *)sender {
     YJAlertListView *alertList = [[YJAlertListView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 20, 400)];
    alertList.datasource = self;
    alertList.delegate = self;
    if (sender.tag == 10) {
        //url
        alertList.tag = 20;
        alertList.titleLabel.text = @"请选择运行环境";
        self.listDataSource = [TFCDataSource urlArray];
    }else {
        //bank
        alertList.tag = 21;
        alertList.titleLabel.text = @"请选择银行";
        self.listDataSource = [TFCDataSource bankArray];
    }
    [alertList show];
    
}
//支付按钮被点击
- (void)payAction:(UIButton *)sender {
    NSMutableArray * mArray = [NSMutableArray array];
    NSMutableArray * paramArray = [NSMutableArray array];
    NSArray *paramNames = [TFCDataSource params];
    for (int i = 0; i < 17; i++) {
        UITextField *tf = [self.scrollView viewWithTag:99 + i];
        if (tf.text.length <= 0 && i != 15) {
            [MBProgressHUD showTipMessageInView:[TFCDataSource placeholders][i] timer:TFC_TOAST_DURATION];
            return;
        }
        if (tf.text.length > 0) {//如果remark字段为空的话，不参与加密和请求
            if (i == 0) {
                //这里是请求URL的textfield
                _urlString = tf.text;
            }else if (i == 13) {
                if (_bankCode) {
                    [mArray addObject:[NSString stringWithFormat:@"%@=%@",paramNames[i],_bankCode]];
                }else {
                    [MBProgressHUD showTipMessageInView:@"请选择银行" timer:TFC_TOAST_DURATION];
                    return;
                }
                
            }else {
                [mArray addObject:[NSString stringWithFormat:@"%@=%@",paramNames[i],tf.text]];
            }
        }
        [paramArray addObject:tf.text];
        _secretKey = tf.text;
    }
    [mArray removeLastObject]; //移除掉秘钥字段
    [mArray addObject:@"cardType=02"]; //cardType:卡类标识  02（信用卡）
    [mArray addObject:[NSString stringWithFormat:@"noise=%@",[TFCUtils randomStringWithLength:32]]]; //noise:随机字符串 不长于32位
    
    //获得签名sign
    NSString *sign = [TFCUtils signWithArray:mArray secretKey:_secretKey];
    if (sign == nil || sign.length <= 0) {
        return;
    }
    
    //拼接参数
    NSString *params = [NSString stringWithFormat:@"%@&sign=%@",[TFCUtils jsonStringWithArray:mArray],sign];
    params = [params stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    //加载菊花
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [mArray removeAllObjects]; //清空数组
    //发起请求
    [TFCHttpRequest postWithUrlString:_urlString parameters:params success:^(NSDictionary *data) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if (data != nil) {
                if ([data[@"code"] isEqualToString:@"SUCCESS"]) {
                    if (data[@"tokenId"] != nil && [data[@"tokenId"] length] > 0) {
                        
                        //存储请求数据
                        [TFCUtils saveValue:paramArray forKey:INFO_KEY];
                        
                        //交易流水号
                        NSString *tn = data[@"tokenId"];
                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                        [[UPPaymentControl defaultControl] startPay:tn fromScheme:@"TFCPayDemo" mode:@"00" viewController:self];
                    }else {
                        //没获取到tn 交易流水号
                        [TFCUtils tfc_showAlertViewWithTitle:data[@"msg"] subTitle:data[@"errCodeDes"] actionTitle:@"知道了"];
                        [MBProgressHUD hideHUDForView:self.view animated:YES];
                    }
                }else {
                    [TFCUtils tfc_showAlertViewWithTitle:data[@"msg"] subTitle:data[@"code"] actionTitle:@"知道了"];
                    [MBProgressHUD hideHUDForView:self.view animated:YES];
                }
            }else {
                [TFCUtils tfc_showAlertViewWithTitle:@"请求异常" subTitle:@"请稍后再试" actionTitle:@"知道了"];
                [MBProgressHUD hideHUDForView:self.view animated:YES];
            }
            
            
        });
        
    } failure:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            [TFCUtils tfc_showAlertViewWithTitle:@"请求异常" subTitle:@"请稍后再试" actionTitle:@"知道了"];
        });
    }];
}

#pragma mark ---YJAlertListView delegate
- (NSInteger)alertListTableView:(YJAlertListView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.listDataSource.count;
}

- (UITableViewCell *)alertListTableView:(YJAlertListView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"identifier";
    UITableViewCell *cell = [tableView dequeueReusableAlertListCellWithIdentifier:identifier];
    if (nil == cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text = [self.listDataSource[indexPath.row] allKeys].lastObject;
    return cell;
}

- (void)alertListTableView:(YJAlertListView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
//某个cell被选中
- (void)alertListTableView:(YJAlertListView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 20) {
        //url
        _urlTf.text = [self.listDataSource[indexPath.row] allValues].lastObject;
    }else {
        //bank
        _bankTf.text = [self.listDataSource[indexPath.row] allKeys].lastObject;
        _bankCode = [self.listDataSource[indexPath.row] allValues].lastObject;
    }
    [tableView dismiss];
}
#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (textField.tag == 99 + 13) {
        return NO;
    }
    return YES;
}

#pragma mark - 其他
//点击手势
- (void)tap:(UIGestureRecognizer *)sender {
    for (int i = 0; i < 17; i++) {
        UITextField *tf = [self.scrollView viewWithTag:99 + i];
        [tf resignFirstResponder];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
