//
//  TFCHttpRequest.h
//  TFCPayDemo
//
//  网络请求工具类
//

#import <Foundation/Foundation.h>

typedef void (^CompletioBlock)(NSDictionary *dic, NSURLResponse *response, NSError *error);
typedef void (^SuccessBlock)(NSDictionary *data);
typedef void (^FailureBlock)(NSError *error);

@interface TFCHttpRequest : NSObject


/**
 get请求

 @param url 请求url字符串
 @param parameters 请求参数
 @param successBlock 请求成功回调
 @param failureBlock 请求失败回调
 */
+ (void)getWithUrlString:(NSString *)url parameters:(NSDictionary *)parameters success:(SuccessBlock)successBlock failure:(FailureBlock)failureBlock;


/**
 post请求

 @param url 请求url字符串
 @param parameters 请求参数
 @param successBlock 请求成功回调
 @param failureBlock 请求失败回调
 */
+ (void)postWithUrlString:(NSString *)url parameters:(NSString *)parameters success:(SuccessBlock)successBlock failure:(FailureBlock)failureBlock;

@end
