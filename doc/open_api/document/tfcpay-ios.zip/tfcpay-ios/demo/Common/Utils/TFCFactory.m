//
//  TFCFactory.m
//  Demo
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//

#import "TFCFactory.h"

#if __has_feature(objc_arc)
#define FA_AUTORELEASE(x) x
#else
#define FA_AUTORELEASE(x) [x autorelease]
#endif

@implementation TFCFactory

+ (UIView *)viewWithFrame:(CGRect)frame backgroundColor:(UIColor *)bgColor
{
    UIView *view = FA_AUTORELEASE([[UIView alloc] init]);
    [view setFrame:frame];
    [view setBackgroundColor:bgColor];
    return view;
}

+ (UILabel *)labelWithFrame:(CGRect)frame text:(NSString *)text
{
    return [self labelWithFrame:frame text:text textColor:[UIColor whiteColor] fontName:nil fontSize:16.0 center:YES];
}

+ (UILabel *)labelWithFrame:(CGRect)frame text:(NSString *)text textColor:(UIColor *)color fontName:(NSString *)name fontSize:(CGFloat)size center:(BOOL)center
{
    UILabel *label = FA_AUTORELEASE([[UILabel alloc] init]);
    label.frame = frame;
    label.text = text;
    label.textColor = color;
    label.numberOfLines = 0;
    label.backgroundColor = [UIColor clearColor];
    if (name == nil) {
        label.font = [UIFont systemFontOfSize:size];
    } else {
        label.font = [UIFont fontWithName:name size:size];
    }
    if (center) {
        label.textAlignment = NSTextAlignmentCenter;
    } else {
        label.textAlignment = NSTextAlignmentLeft;
    }
    return label;
}

+ (UIButton *)buttonWithFrame:(CGRect)frame image:(UIImage *)image highlightedImage:(UIImage *)highlightedImage title:(NSString *)title titleColor:(UIColor *)color
{
    return [self buttonWithFrame:frame image:image highlightedImage:highlightedImage title:title titleColor:color fontName:nil fontSize:16.0];
}

+ (UIButton *)buttonWithFrame:(CGRect)frame image:(UIImage *)image highlightedImage:(UIImage *)highlightedImage title:(NSString *)title titleColor:(UIColor *)color fontName:(NSString *)name fontSize:(CGFloat)size
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.layer.cornerRadius = 4;
    button.layer.masksToBounds = YES;
    if (image) {
        // 设置端盖的值
        CGFloat top = image.size.height * 0.5;
        CGFloat left = image.size.width * 0.5;
        image = [image stretchableImageWithLeftCapWidth:left topCapHeight:top];
        [button setBackgroundImage:image forState:UIControlStateNormal];
    }
    if (highlightedImage) {
        
        CGFloat highlightedTop = highlightedImage.size.height * 0.5;
        CGFloat highlightedLeft = highlightedImage.size.width * 0.5;
        highlightedImage = [highlightedImage stretchableImageWithLeftCapWidth:highlightedLeft topCapHeight:highlightedTop];
        [button setBackgroundImage:highlightedImage forState:UIControlStateHighlighted];
    }
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:color forState:UIControlStateNormal];
    if (name == nil) {
        button.titleLabel.font = [UIFont systemFontOfSize:size];
    } else {
        button.titleLabel.font = [UIFont fontWithName:name size:size];
    }
    return button;
}

+ (UIButton *)buttonWithFrame:(CGRect)frame image:(UIImage *)image highlightedImage:(UIImage *)highlightedImage
{
    return [self buttonWithFrame:frame backgroundImage:nil highlightedBackgroundImage:nil image:image highlightedImage:highlightedImage];
}

+ (UIButton *)buttonWithFrame:(CGRect)frame backgroundImage:(UIImage *)bgImage highlightedBackgroundImage:(UIImage *)highlightedBgImage image:(UIImage *)image highlightedImage:(UIImage *)highlightedImage
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    if (bgImage) {
        [button setBackgroundImage:bgImage forState:UIControlStateNormal];
    }
    if (highlightedBgImage) {
        [button setBackgroundImage:highlightedBgImage forState:UIControlStateHighlighted];
    }
    if (image) {
        [button setImage:image forState:UIControlStateNormal];
    }
    if (highlightedImage) {
        [button setImage:highlightedImage forState:UIControlStateHighlighted];
    }
    return button;
}

+ (UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)color highlighted:(BOOL)highlighted highlightedColor:(UIColor *)highlightedColor
{
    return [self buttonWithFrame:frame title:title titleColor:color fontName:nil fontSize:16.0 highlighted:highlighted highlightedColor:highlightedColor];
}

+ (UIButton *)buttonWithFrame:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)color fontName:(NSString *)name fontSize:(CGFloat)size highlighted:(BOOL)highlighted highlightedColor:(UIColor *)highlightedColor
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    if (title) {
        [button setTitle:title forState:UIControlStateNormal];
    }
    if (name == nil) {
        button.titleLabel.font = [UIFont systemFontOfSize:size];
    } else {
        button.titleLabel.font = [UIFont fontWithName:name size:size];
    }
    if (color) {
        [button setTitleColor:color forState:UIControlStateNormal];
    }
    if (highlighted && highlightedColor) {
        [button setTitleColor:highlightedColor forState:UIControlStateHighlighted];
    }
    return button;
}

+ (UIImageView *)imageViewWithFrame:(CGRect)frame image:(UIImage *)image
{
    return [self imageViewWithFrame:frame image:image contentMode:UIViewContentModeScaleToFill userInteractionEnabled:YES];
}

+ (UIImageView *)imageViewWithFrame:(CGRect)frame image:(UIImage *)image contentMode:(NSInteger)contentMode userInteractionEnabled:(BOOL)enabled
{
    UIImageView *imageView = FA_AUTORELEASE([[UIImageView alloc] init]);
    imageView.frame = frame;
    if (image) {
        // 设置端盖的值
        CGFloat top = image.size.height * 0.5;
        CGFloat left = image.size.width * 0.5;
        image = [image stretchableImageWithLeftCapWidth:left topCapHeight:top];
        imageView.image = image;
    }
    imageView.contentMode = contentMode;
    if (enabled) {
        imageView.userInteractionEnabled = YES;
    }
    return imageView;
}

+ (UITextField *)textFieldWithFrame:(CGRect)frame placeholder:(NSString *)placeholder text:(NSString *)text borderStyle:(NSInteger)borderStyle backgroundColor:(UIColor *)bgColor delegate:(id)delegate
{
    return [self textFieldWithFrame:frame placeholder:placeholder text:text borderStyle:borderStyle backgroundColor:bgColor delegate:delegate returnKeyType:UIReturnKeyDefault keyboardType:UIKeyboardTypeDefault fontName:nil fontSize:16.0 secure:NO];
}

+ (UITextField *)textFieldWithFrame:(CGRect)frame placeholder:(NSString *)placeholder text:(NSString *)text borderStyle:(NSInteger)borderStyle backgroundColor:(UIColor *)bgColor delegate:(id)delegate returnKeyType:(NSInteger)returnKeyType keyboardType:(NSInteger)keyboardType fontName:(NSString *)fontName fontSize:(CGFloat)fontSize secure:(BOOL)secure
{
    UITextField *textField = FA_AUTORELEASE([[UITextField alloc] init]);
    textField.frame = frame;
    textField.placeholder = placeholder;
    textField.text = text;
    textField.delegate = delegate;
    textField.borderStyle = borderStyle;
    textField.backgroundColor = bgColor;
    textField.returnKeyType = returnKeyType;
    textField.keyboardType = keyboardType;
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
//    textField.layer.borderWidth = 1;
    UIImageView * leftView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 0, frame.size.height)];
    textField.leftView = leftView;
    textField.leftViewMode = UITextFieldViewModeAlways;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    if (secure) {
        textField.secureTextEntry = YES;
    }
    if (fontName == nil) {
        textField.font = [UIFont systemFontOfSize:fontSize];
    } else {
        textField.font = [UIFont fontWithName:fontName size:fontSize];
    }
    return textField;
}

+ (UITextView *)textViewWithFrame:(CGRect)frame text:(NSString *)text isEditable:(BOOL)isEditable
{
    UITextView *textView = FA_AUTORELEASE([[UITextView alloc] init]);
    textView.frame = frame;
    textView.text = text;
    textView.editable = isEditable;
    return textView;
}

+ (UIImage *)drawLineByImageView:(UIImageView *)imageView{
    UIGraphicsBeginImageContext(imageView.frame.size); //开始画线 划线的frame
    [imageView.image drawInRect:CGRectMake(0, 0, imageView.frame.size.width, imageView.frame.size.height)];
    //设置线条终点形状
    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    // 5是每个虚线的长度 1是高度
    CGFloat lengths[] = {4,0.5};
    CGContextRef line = UIGraphicsGetCurrentContext();
    // 设置颜色
    CGContextSetStrokeColorWithColor(line, [UIColor colorWithRed:188/255.0 green:188/255.0 blue:188/255.0 alpha:1].CGColor);
    CGContextSetLineDash(line, 0, lengths, 2); //画虚线
    
    CGContextMoveToPoint(line, 0.0, 1.0); //开始画线
    CGContextAddLineToPoint(line, imageView.frame.size.width, 1.0);
    
    CGContextStrokePath(line);
    // UIGraphicsGetImageFromCurrentImageContext()返回的就是image
    return UIGraphicsGetImageFromCurrentImageContext();
}
@end
