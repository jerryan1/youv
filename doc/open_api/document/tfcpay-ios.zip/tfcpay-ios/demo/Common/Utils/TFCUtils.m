//
//  TFCUtils.m
//  TFCDemo
//
//  Created by ccy on 2017/9/25.
//  Copyright © 2017年 ccy. All rights reserved.
//

#import "TFCUtils.h"
#import <CommonCrypto/CommonDigest.h>

@implementation TFCUtils

+ (NSString *) md5:(NSString *) anString
{
    if (!anString) {
        return nil;
    }
    const char *cStr = [anString UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5(cStr, (CC_LONG)strlen(cStr), digest);
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH*2];
    for(int i = 0; i < CC_MD5_DIGEST_LENGTH; i++)
        [result appendFormat:@"%02x", digest[i]];
    return result;
}

+ (NSString *)randomStringWithLength:(NSInteger)len {
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    
    for (NSInteger i = 0; i < len; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random_uniform((uint32_t)[letters length])]];
    }
    return randomString;
}

+ (void)tfc_showAlertViewWithTitle:(NSString *)title subTitle:(NSString *)subTitle actionTitle:(NSString *)actionTitle
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:subTitle preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alert addAction:action];
    [[self tfc_fetchCurrentViewController] presentViewController:alert animated:YES completion:nil];
}

+ (UIViewController *)tfc_fetchCurrentViewController
{
    UIViewController *rvc = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (rvc.presentedViewController) {
        rvc = rvc.presentedViewController;
    }
    return rvc;
}

+ (NSString *)timeStamp
{
    NSTimeInterval timeInterval = [[NSDate date] timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%ld", (long)timeInterval];
    return timeString;
}

+ (NSString *)jsonStringWithArray:(NSArray <NSString *>*)array
{
    __block NSString *jsonString = @"";
    [array enumerateObjectsUsingBlock:^(NSString * obj, NSUInteger idx, BOOL * _Nonnull stop) {
        jsonString = [jsonString stringByAppendingString:obj];
        if (idx < array.count - 1) {
            jsonString = [jsonString stringByAppendingString:@"&"];
        }
    }];
    return jsonString;
}

+ (NSString *)signWithArray:(NSArray *)array secretKey:(NSString *)secretKey
{
    //对数组元素进行自然排序
    NSArray *arr = [array sortedArrayUsingSelector:@selector(compare:)];
    //将数组中的元素拼接成一个字符串
    NSString *sign = [self jsonStringWithArray:arr];
    //在字符串末尾拼接上秘钥
    sign = [sign stringByAppendingString:[NSString stringWithFormat:@"&%@",secretKey]];
    //字符串md5加密
    sign = [self md5:sign];
    //字符串转大写
    sign = [sign uppercaseString];
    
    return sign;
}

+(void)saveValue:(id) value forKey:(NSString *)key{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:value forKey:key];
    [userDefaults synchronize];
}

+(id)valueForKey:(NSString *)key{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [userDefaults objectForKey:key];
}

+(id)StringForKey:(NSString *)key{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [userDefaults stringForKey:key];
}

+(BOOL)boolValueForKey:(NSString *)key{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    return [userDefaults boolForKey:key];
}

+(void)saveBoolValue:(BOOL)value forKey:(NSString *)key{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setBool:value forKey:key];
    [userDefaults synchronize];
}

+(void)printAllUserDefault{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *dic = [userDefaults dictionaryRepresentation];
    NSLog(@"%@",dic);
}

@end
