//
//  TFCMacros.h
//  Demo
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//

#ifndef TFCMacros_h
#define TFCMacros_h

//立即消失
#define TFC_NEWS_DISAPPEAR 0
//动画消失缓冲时间
#define TFC_NEWS_DURATION 0.5
//Toast显示时间
#define TFC_TOAST_DURATION 2.0

//主窗口
#define TFC_KEYWINDOW [UIApplication sharedApplication].keyWindow

//Hex转化颜色
#define TFCCOLOR(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 \
green:((float)((hex & 0xFF00) >> 8))/255.0    \
blue:((float)(hex & 0xFF))/255.0 alpha:1.0]

//RGB颜色
#define TFCRGB(r, g, b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0  alpha:1.0]
#define TFCRGBA(r, g, b, a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

//清除颜色
#define TFCCLEARCOLOR [UIColor clearColor]

//屏幕宽和度
#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

//状态栏高度
#define STATUS_BAR_HEIGHT [[UIApplication sharedApplication] statusBarFrame].size.height

//导航栏高度
#define NAVIGATION_BAR_HEIGHT self.navigationController.navigationBar.frame.size.height

//本地存储
#define USER_DEFAULTS [NSUserDefaults standardUserDefaults]

//系统版本号
#define SYS_VERSION [[UIDevice currentDevice].systemVersion floatValue]

//通知中心
#define NOTIFI_CENTER [NSNotificationCenter defaultCenter]

#endif /* TFCMacros_h */
