//
//  TFCUtils.h
//  TFCDemo
//
//  Created by ccy on 2017/9/25.
//  Copyright © 2017年 ccy. All rights reserved.
//  工具类

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface TFCUtils : NSObject

/**
 MD5加密字符串

 @param anString 待加密字符串
 @return md5加密之后的字符串
 */
+ (NSString *) md5:(NSString *) anString;

/**
 随机字符串
 
 @param length 随机字符串长度
 @return 字符串
 */
+ (NSString *)randomStringWithLength:(NSInteger)length;

/**
 提示框
 
 @param title 标题
 @param subTitle 副标题
 @param actionTitle 按钮title
 */
+ (void)tfc_showAlertViewWithTitle:(NSString *)title subTitle:(NSString *)subTitle actionTitle:(NSString *)actionTitle;

/**
 获取当前视图控制器
 
 @return 视图控制器
 */
+ (UIViewController *)tfc_fetchCurrentViewController;

/**
 获取时间戳(可作为模拟订单号)

 @return 时间戳
 */
+ (NSString *)timeStamp;

/**
 将数组中的字符串元素 ，拼接成一个字符串

 @param array 每个元素均为字符串的数组
 @return 拼接好的字符串
 */
+ (NSString *)jsonStringWithArray:(NSArray <NSString *>*)array;

/**
 对数组元素，进行加密，生成sign签名

 @param array 待加密数组
 @param secretKey 加密秘钥
 @return sign签名
 */
+ (NSString *)signWithArray:(NSArray *)array secretKey:(NSString *)secretKey;

/********************* UserDefaultUtil **************************/

+(void)saveValue:(id) value forKey:(NSString *)key;

+(id)valueForKey:(NSString *)key;

+(id)StringForKey:(NSString *)key;

+(void)saveBoolValue:(BOOL)value forKey:(NSString *)key;

+(BOOL)boolValueForKey:(NSString *)key;

+(void)printAllUserDefault;

@end
