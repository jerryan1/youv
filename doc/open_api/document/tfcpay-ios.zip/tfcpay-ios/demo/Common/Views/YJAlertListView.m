//
//  YJAlertListView.m
//  Demo
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//

#import "YJAlertListView.h"
#import "TFCMacros.h"

static CGFloat ZJCustomButtonHeight = 44;
static UIButton *_cover;

@interface YJAlertListView ()

@property (nonatomic, strong) UITableView *mainAlertListView;

@end

@implementation YJAlertListView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initTheInterface];
    }
    return self;
}
//对弹框的布局
- (void)initTheInterface {
    self.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    self.layer.borderWidth = 1.0f;
    self.layer.cornerRadius = 10.0f;
    self.clipsToBounds = TRUE;
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.titleLabel.font = [UIFont systemFontOfSize:17.0f];
    self.titleLabel.backgroundColor = TFCRGB(54, 155, 247);
    
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.textColor = [UIColor whiteColor];
    CGFloat xWidth = self.bounds.size.width;
    //显示不全的情况下，省略号的位置
    self.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    self.titleLabel.frame = CGRectMake(0, 0, xWidth, ZJCustomButtonHeight);
    [self addSubview:self.titleLabel];
    
    CGRect tableFrame = CGRectMake(0, ZJCustomButtonHeight, xWidth, self.bounds.size.height - ZJCustomButtonHeight);
    _mainAlertListView = [[UITableView alloc] initWithFrame:tableFrame style:UITableViewStylePlain];
    self.mainAlertListView.dataSource = self;
    self.mainAlertListView.delegate = self;
    [self addSubview:self.mainAlertListView];
    
}

- (NSIndexPath *)indexPathForSelectedRow
{
    return [self.mainAlertListView indexPathForSelectedRow];
}

#pragma mark - UITableViewDatasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.datasource && [self.datasource respondsToSelector:@selector(alertListTableView:numberOfRowsInSection:)])
    {
        return [self.datasource alertListTableView:self numberOfRowsInSection:section];
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.datasource && [self.datasource respondsToSelector:@selector(alertListTableView:cellForRowAtIndexPath:)])
    {
        return [self.datasource alertListTableView:self cellForRowAtIndexPath:indexPath];
    }
    return nil;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(alertListTableView:didDeselectRowAtIndexPath:)])
    {
        [self.delegate alertListTableView:self didDeselectRowAtIndexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(alertListTableView:didSelectRowAtIndexPath:)])
    {
        [self.delegate alertListTableView:self didSelectRowAtIndexPath:indexPath];
    }
}

#pragma mark - Animated Mthod
- (void)animatedIn
{
    self.transform = CGAffineTransformMakeScale(1.3, 1.3);
    self.alpha = 0;
    [UIView animateWithDuration:.35 animations:^{
        self.alpha = 1;
        self.transform = CGAffineTransformMakeScale(1, 1);
    }];
}

- (void)animatedOut
{
    [UIView animateWithDuration:.35 animations:^{
        [self removeFromSuperview];
        [_cover removeFromSuperview];
        _cover = nil;
    }];
}

- (void)show
{
    UIWindow *keywindow = [[UIApplication sharedApplication].windows lastObject];
    keywindow.windowLevel = UIWindowLevelNormal;
    
    // 遮盖
    UIButton *cover = [[UIButton alloc] init];
    cover.backgroundColor = [UIColor blackColor];
    cover.alpha = 0.4;
    [cover addTarget:self action:@selector(animatedOut) forControlEvents:UIControlEventTouchUpInside];
    cover.frame = [UIScreen mainScreen].bounds;
    _cover = cover;
    
    [keywindow addSubview:cover];
    [keywindow addSubview:self];
    
    self.center = CGPointMake(keywindow.bounds.size.width/2.0f,
                              keywindow.bounds.size.height/2.0f);
    
    [self animatedIn];
}

- (void)dismiss
{
    [self animatedOut];
}

- (id)dequeueReusableAlertListCellWithIdentifier:(NSString *)identifier
{
    return [self.mainAlertListView dequeueReusableCellWithIdentifier:identifier];
}

- (UITableViewCell *)alertListCellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.mainAlertListView reloadData];
    return [self.mainAlertListView cellForRowAtIndexPath:indexPath];
}


@end
