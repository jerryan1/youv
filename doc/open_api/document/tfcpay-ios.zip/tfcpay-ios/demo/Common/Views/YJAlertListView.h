//
//  YJAlertListView.h
//  Demo
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YJAlertListView;

//YJAlertListView数据源方法
@protocol YJAlertListViewDatasource <NSObject>

//YJAlertListView有多少行
- (NSInteger)alertListTableView:(YJAlertListView *)tableView numberOfRowsInSection:(NSInteger)section;
//YJAlertListView每个cell的样式
- (UITableViewCell *)alertListTableView:(YJAlertListView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

@end

//代理方法
@protocol YJAlertListViewDelegate <NSObject>
//YJAlertListView cell的选中
- (void)alertListTableView:(YJAlertListView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
//YJAlertListView cell为被选中
- (void)alertListTableView:(YJAlertListView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface YJAlertListView : UIView<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) id <YJAlertListViewDatasource> datasource;

@property (nonatomic, weak) id <YJAlertListViewDelegate> delegate;

//view的标题
@property (nonatomic, strong) UILabel *titleLabel;


//YJAlertListView展示界面
- (void)show;

//YJAlertListView消失界面
- (void)dismiss;

//列表cell的重用
- (id)dequeueReusableAlertListCellWithIdentifier:(NSString *)identifier;

- (UITableViewCell *)alertListCellForRowAtIndexPath:(NSIndexPath *)indexPath;

//选中的列表元素
- (NSIndexPath *)indexPathForSelectedRow;

@end
