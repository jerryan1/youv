//
//  TFCDataSource.m
//  Demo1
//
//  Created by ccy on 2017/9/26.
//  Copyright © 2017年 ccy. All rights reserved.
//

#import "TFCDataSource.h"

@implementation TFCDataSource
+ (NSArray *)titleArray
{
    NSArray *titleArray = @[@"商户号",@"通知URL",@"外部交易号",@"交易金额",@"商品名称",@"商品描述",@"付款人银行卡",@"付款人身份证号",@"付款人手机号",@"选择银行编码",@"备注",@"秘钥"];
    return titleArray;
}

+ (NSArray *)placeholders
{
    NSArray *placeholders = @[@"请输入商户号",@"请输入通知URL",@"请输入交易号",@"请输入交易金额",@"请输入商品名称",@"请输入商品描述",@"请输入付款人银行卡号",@"请输入付款人身份证号",@"请输入付款人手机号",@"请选择付款人银行编码",@"请输入备注",@"请输入秘钥"];
    return placeholders;
}

+ (NSArray *)bankArray
{
    /*
     bank.plist key：银行名称  value：银行编码
     */
    NSString *path = [[NSBundle mainBundle] pathForResource:@"bank.plist" ofType:nil];
    NSArray *bankArray = [NSArray arrayWithContentsOfFile:path];
    return bankArray;
}

+ (NSArray *)urlArray
{
    NSArray *urlArray = @[];
    return urlArray;
}

+ (NSArray *)params
{
    /*
     请求参数介绍
     mid:商户号
     notifyUrl:针对该交易的交易状态同步通知接受URL(如不填写,则收不到通知)
     orderNo:合作伙伴交易号（确保在合作伙伴系统中唯一）
     amount:交易的总金额，单位为元
     subject:商品的标题
     body:商品的具体描述
     bankCardNo:付款方银行卡号
     
     cardId:付款方身份证号
     phoneNo:付款方手机号码
     bankCode:付款方银行编码
     remark:备注 （可以为空）
     secretKey: md5加密秘钥
     noise: 随机字符串,不长于32位
     sign:数据的加密校验字符串，目前只支持使用MD5签名算法对待签名数据进行签名
     */
    NSArray *params = @[@"mid",@"notifyUrl",@"orderNo",@"amount",@"subject",@"body",@"bankCardNo",@"cardId",@"phoneNo",@"bankCode",@"remark",@"secretKey",@"noise"];
    
    return params;
}
@end
