//
//  WebViewController.h
//  Demo1
//
//  Created by ccy on 2017/9/25.
//  Copyright © 2017年 ccy. All rights reserved.
//
/*
 该类使用WebView加载后台返回的HTML字符串，进行支付工作。
 */

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController
/**
 html 字符串
 */
@property (nonatomic, copy)NSString *urlString;

@end
