//
//  ViewController.m
//  Demo1
//
//  Created by ccy on 2017/9/25.
//  Copyright © 2017年 ccy. All rights reserved.
//

/*!
 填写支付信息界面
 界面中显示的参数，除了备注（remark）字段，其余均不能为空
 填写完毕，点击支付按钮，跳转页面进行支付
 */

#import "ViewController.h"
#import "TFCHttpRequest.h"
#import "TFCUtils.h"
#import "MBProgressHUD+YJMethod.h"
#import "WebViewController.h"
#import "YJAlertListView.h"
#import "TFCFactory.h"
#import "TFCMacros.h"
#import "TFCDataSource.h"

#define INFO_KEY @"info_key2"

@interface ViewController ()<YJAlertListViewDelegate, YJAlertListViewDatasource, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic, strong) NSIndexPath *selectedIndexPath;
/** YJAlertListView */
@property (nonatomic, strong)  YJAlertListView *listView;
@end

@implementation ViewController {
    NSArray *_titleArray;
    NSArray *_placeholders;
    NSArray *_bankArray;
    NSArray *_paramArray;
    NSString *_bankCode;
    NSString *_bankName;
    UITextField *_bankTf;
    NSInteger _margin;
    NSInteger _height;
    NSString *_noise;
    NSString *_secretKey;
    NSString *_requestUrl;
    NSArray *_textInfo;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _margin = 10;
    _height = 30;
    _noise = [TFCUtils randomStringWithLength:11]; //随机字符串 参数要求，长度不可超过32位
    
    //请求地址
//    _requestUrl = @"http://192.168.5.203:8080/leopard-netpay-web/quickPay/quickPayB2c";
    _requestUrl = @"http://192.168.9.121/v2/quickPay/quickPayB2c";
    
    [self createDataSource];
    
    [self createUI];
}

- (void)createDataSource {
    _titleArray = [TFCDataSource titleArray];
    _placeholders = [TFCDataSource placeholders];
    _bankArray = [TFCDataSource bankArray];
    _paramArray = [TFCDataSource params];
//    _textInfo = @[@"822017092124477",@"http://192.168.9.89:8081/shopDemo/notify",[TFCUtils timeStamp],@"100",@"subject",@"body",@"6225758342665071",@"230306199211194510",@"18811077354",@"招商银行",@"",@"pf178em2cnkt1317cy26"];
    _textInfo = @[@"822017092425663",@"http://192.168.9.89:8081/shopDemo/notify",[TFCUtils timeStamp],@"100",@"subject",@"body",@"6222020200098847771",@"130421199101095437",@"15230022876",@"招商银行",@"",@"3j0c5eq382thvwmv9ekl"];
}

//创建UI视图
- (void)createUI {
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH, _titleArray.count * (_margin + _height) + _margin + 248);
    self.scrollView.showsVerticalScrollIndicator = NO;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    [self.scrollView addGestureRecognizer:tap];
    NSArray *payInfo;
    if ([TFCUtils valueForKey:INFO_KEY]) {
        payInfo = [TFCUtils valueForKey:INFO_KEY];
    }
    
    for (int i = 0; i< _titleArray.count; i++) {
        UILabel *label = [[UILabel alloc]init];
        label.frame = CGRectMake(_margin, _margin * (i + 1) + _height * i, 100, _height);
        label.font = [UIFont systemFontOfSize:14];
        label.text = _titleArray[i];
        label.textColor = [UIColor blackColor];
        label.textAlignment = NSTextAlignmentLeft;
        [self.scrollView addSubview:label];
        
        UITextField *textField = [TFCFactory textFieldWithFrame: CGRectMake(120 + _margin, _margin * (i + 1) + _height * i, SCREEN_WIDTH - 120 - _margin, _height) placeholder:_placeholders[i] text:nil borderStyle:0 backgroundColor:[UIColor whiteColor] delegate:self];
        textField.tag = 99 + i;
        [self.scrollView addSubview:textField];
        
        if (i == 9) {
            textField.frame = CGRectMake(120 + _margin, _margin * (i + 1) + _height * i, SCREEN_WIDTH - 120 - _margin - 90, _height);
            textField.userInteractionEnabled = NO;
            _bankTf = textField;
            UIButton *button = [TFCFactory buttonWithFrame:CGRectMake(SCREEN_WIDTH - 80, _margin * (i + 1) + _height * i, 80, _height) image:[UIImage imageNamed:@"btn2_bg_normal"] highlightedImage:[UIImage imageNamed:@"btn2_bg_select"] title:@"选择银行" titleColor:[UIColor whiteColor] fontName:nil fontSize:16];
            [button addTarget:self action:@selector(selectBank:) forControlEvents:UIControlEventTouchUpInside];
            [self.scrollView addSubview:button];
        }else {
            if (payInfo.count == 13) {
                if (i != 2) {
                    textField.text = payInfo[i];
                }
            }
            textField.text = _textInfo[i];
        }
        //添加一个分隔线
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(textField.frame.origin.x, textField.frame.origin.y + textField.frame.size.height - 1, textField.frame.size.width, 1)];
        lineView.backgroundColor = [UIColor grayColor];
        [self.scrollView addSubview:lineView];
        
    }
}
//选择银行按钮点击
- (void)selectBank:(UIButton *)sender {
    YJAlertListView *alertList = [[YJAlertListView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 20, 400)];
    alertList.titleLabel.text = @"请选择银行";
    alertList.datasource = self;
    alertList.delegate = self;
    [alertList show];
}

//支付按钮点击
- (IBAction)payAction:(UIButton *)sender {
    
    NSMutableArray * mArray = [NSMutableArray array];
    
    NSMutableArray * paramArray = [NSMutableArray array];
    for (int i = 0; i < _titleArray.count; i++) {
        UITextField *tf = [self.scrollView viewWithTag:99 + i];
        if (tf.text.length <= 0 && (i != _titleArray.count - 2)) {
            //remark字段可以为空
            [MBProgressHUD showTipMessageInView:_placeholders[i] timer:TFC_TOAST_DURATION];
            return ;
        }
        if (tf.text.length > 0) { //如果remark字段为空的话，不参与加密和请求
            if (i != 9) {
                [mArray addObject:[NSString stringWithFormat:@"%@=%@",_paramArray[i],tf.text]];
            }else {
                if (_bankCode) {
                    [mArray addObject:[NSString stringWithFormat:@"%@=%@",_paramArray[i],_bankCode]];
                }else {
                    [MBProgressHUD showTipMessageInView:@"请选择银行" timer:TFC_TOAST_DURATION];
                    return;
                }
            }
        }
        
        [paramArray addObject:tf.text];
        _secretKey = tf.text;
    }
    [mArray removeLastObject];//移除掉秘钥字段
    
    [mArray addObject:[NSString stringWithFormat:@"noise=%@",_noise]];
    //获得签名sign
    NSString *sign = [TFCUtils signWithArray:mArray secretKey:_secretKey];
    if (sign == nil || sign.length <= 0) {
        return;
    }
    NSString *params = [NSString stringWithFormat:@"%@&sign=%@",[TFCUtils jsonStringWithArray:mArray],sign]; //拼接参数
    params = [params stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    //加载菊花
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    //发起网络请求，获取HTML 字符串
    [TFCHttpRequest postWithUrlString:_requestUrl parameters:params success:^(NSDictionary *data) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            if (data != nil) {
                
                if ([data[@"code"] isEqualToString:@"SUCCESS"]) {
                    //存储数据
                    [TFCUtils saveValue:paramArray forKey:INFO_KEY];
                    
                    //交易流水号
                    NSString *html = data[@"html"];
                    if (html.length > 0 && html != nil) {
                        WebViewController *vc = [[WebViewController alloc]init];
                        vc.urlString = html;
                        [self.navigationController pushViewController:vc animated:YES];
                    }else {
                        [TFCUtils tfc_showAlertViewWithTitle:@"请求异常" subTitle:@"返回HTML字段为空" actionTitle:@"知道了"];
                    }
                }else {
                    [TFCUtils tfc_showAlertViewWithTitle:data[@"msg"] subTitle:data[@"code"] actionTitle:@"知道了"];
                }
            }else {
                [TFCUtils tfc_showAlertViewWithTitle:@"请求异常" subTitle:@"请稍后再试" actionTitle:@"知道了"];
            }
        });
    } failure:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:self.view animated:YES];
            [TFCUtils tfc_showAlertViewWithTitle:@"请求异常" subTitle:@"请稍后再试" actionTitle:@"知道了"];
        });
    }];
    
}

#pragma mark ---YJAlertListView delegate
- (NSInteger)alertListTableView:(YJAlertListView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _bankArray.count;
}

- (UITableViewCell *)alertListTableView:(YJAlertListView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"identifier";
    UITableViewCell *cell = [tableView dequeueReusableAlertListCellWithIdentifier:identifier];
    if (nil == cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text = [_bankArray[indexPath.row] allKeys].lastObject;
    return cell;
}

- (void)alertListTableView:(YJAlertListView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
//某个cell被选中
- (void)alertListTableView:(YJAlertListView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //bank
    _bankTf.text = [_bankArray[indexPath.row] allKeys].lastObject;
    _bankCode = [_bankArray[indexPath.row] allValues].lastObject;
    [tableView dismiss];
}

#pragma mark - 其他
//点击手势
- (void)tap:(UIGestureRecognizer *)sender {
    for (int i = 0; i < _titleArray.count; i++) {
        UITextField *tf = [self.scrollView viewWithTag:99 + i];
        [tf resignFirstResponder];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
