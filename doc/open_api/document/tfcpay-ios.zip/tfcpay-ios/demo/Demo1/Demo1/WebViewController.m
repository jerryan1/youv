//
//  WebViewController.m
//  Demo1
//
//  Created by ccy on 2017/9/25.
//  Copyright © 2017年 ccy. All rights reserved.
//  

#import "WebViewController.h"
#import "TFCMacros.h"
@interface WebViewController ()
@property (nonatomic, strong)UIWebView *webView;
@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"支付";
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self.view addSubview:self.webView];
    //加载HTML界面
    [self.webView loadHTMLString:self.urlString baseURL:nil];
}

/**
 懒加载webView
 
 @return webView
 */
- (UIWebView *)webView {
    if (!_webView) {
        CGFloat topHeight = STATUS_BAR_HEIGHT + NAVIGATION_BAR_HEIGHT;
        _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, topHeight, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - topHeight)];
    }
    return _webView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
